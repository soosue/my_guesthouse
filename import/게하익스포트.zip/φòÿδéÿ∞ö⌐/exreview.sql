--------------------------------------------------------
--  파일이 생성됨 - 일요일-6월-14-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table EXREVIEW
--------------------------------------------------------

  CREATE TABLE "PROJECT"."EXREVIEW" 
   (	"EXRESERVECODE" NUMBER(5,0), 
	"MEMBERCODE" NUMBER(10,0), 
	"REVDATE" DATE, 
	"REVCONTENT" VARCHAR2(1000 BYTE), 
	"REVRATE" NUMBER(5,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into PROJECT.EXREVIEW
SET DEFINE OFF;
Insert into PROJECT.EXREVIEW (EXRESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (126,41,to_date('20/01/06','RR/MM/DD'),'제주도 야경이 너무 예뻐요!',4);
Insert into PROJECT.EXREVIEW (EXRESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (127,43,to_date('20/01/06','RR/MM/DD'),'별자리 얘기도 해주시고 너무 유익했어요~~',5);
Insert into PROJECT.EXREVIEW (EXRESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (128,41,to_date('20/01/06','RR/MM/DD'),'목장체험 처음인데 알파카 넘 귀여워요!! 제주도 갈 때 마다 갈게요 *^^*  ',5);
Insert into PROJECT.EXREVIEW (EXRESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (129,41,to_date('20/01/06','RR/MM/DD'),'향초인줄알고 만들었는데 냄새가안나요',1);
Insert into PROJECT.EXREVIEW (EXRESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (130,41,to_date('20/01/06','RR/MM/DD'),'컵 만들기 너무 재밋어요!! 택배 배송이 오래 걸렸지만 너무 예뻐요~~~',5);
Insert into PROJECT.EXREVIEW (EXRESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (131,43,to_date('20/01/06','RR/MM/DD'),'알파카는 털관리는 안하나요? 너무 떡져있어요...ㅜㅜㅜㅜㅜ만질수가없어요ㅠㅜㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠ
',2);
Insert into PROJECT.EXREVIEW (EXRESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (132,43,to_date('20/01/06','RR/MM/DD'),'캔들 넘예뻐여~~~또 갈게용',5);
Insert into PROJECT.EXREVIEW (EXRESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (133,163,to_date('20/01/06','RR/MM/DD'),'알파카 딱 기다려라 ^ㅅ^',5);
Insert into PROJECT.EXREVIEW (EXRESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (134,62,to_date('20/01/06','RR/MM/DD'),'데프트 30마리 -ㅅ-',5);
Insert into PROJECT.EXREVIEW (EXRESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (135,46,to_date('20/01/06','RR/MM/DD'),'알파카 너무 귀여워~~ 집에 데려가고싶어!! 근데 위생은 별로네요',1);
--------------------------------------------------------
--  Constraints for Table EXREVIEW
--------------------------------------------------------

  ALTER TABLE "PROJECT"."EXREVIEW" MODIFY ("EXRESERVECODE" NOT NULL ENABLE);

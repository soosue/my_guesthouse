--------------------------------------------------------
--  파일이 생성됨 - 일요일-6월-14-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table EXREMAIN
--------------------------------------------------------

  CREATE TABLE "PROJECT"."EXREMAIN" 
   (	"RESDATE" DATE, 
	"EXPEOPLE" NUMBER(10,0), 
	"EXCODE" NUMBER(5,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into PROJECT.EXREMAIN
SET DEFINE OFF;
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/07','RR/MM/DD'),1,41);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/07','RR/MM/DD'),1,32);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/07','RR/MM/DD'),1,17);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/07','RR/MM/DD'),1,41);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/07','RR/MM/DD'),1,32);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/10','RR/MM/DD'),9,41);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/12','RR/MM/DD'),10,41);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/06','RR/MM/DD'),1,41);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/07','RR/MM/DD'),1,41);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/07','RR/MM/DD'),1,1);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/08','RR/MM/DD'),1,1);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/11','RR/MM/DD'),8,41);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/01/16','RR/MM/DD'),4,41);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/02/05','RR/MM/DD'),2,3);
Insert into PROJECT.EXREMAIN (RESDATE,EXPEOPLE,EXCODE) values (to_date('20/02/18','RR/MM/DD'),4,8);
--------------------------------------------------------
--  Constraints for Table EXREMAIN
--------------------------------------------------------

  ALTER TABLE "PROJECT"."EXREMAIN" MODIFY ("EXCODE" NOT NULL ENABLE);

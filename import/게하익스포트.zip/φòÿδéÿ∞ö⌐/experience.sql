--------------------------------------------------------
--  파일이 생성됨 - 일요일-6월-14-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table EXPERIENCE
--------------------------------------------------------

  CREATE TABLE "PROJECT"."EXPERIENCE" 
   (	"EXCODE" NUMBER(5,0), 
	"MEMBERCODE" NUMBER(10,0), 
	"EXNAME" VARCHAR2(1000 BYTE), 
	"EXPEOPLE" NUMBER(2,0), 
	"EXSTARTDATE" DATE, 
	"EXENDDATE" DATE, 
	"EXTIME" VARCHAR2(10 BYTE), 
	"EXPRICE" NUMBER(10,0), 
	"EXADDRESS" VARCHAR2(255 BYTE), 
	"EXEXPLAIN" VARCHAR2(4000 BYTE), 
	"EXAPPROVAL" VARCHAR2(300 BYTE), 
	"EXBANK" VARCHAR2(300 BYTE), 
	"EXACCOUNT" NUMBER(15,0), 
	"EXREGDATE" DATE, 
	"HOUSECODE" NUMBER(10,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into PROJECT.EXPERIENCE
SET DEFINE OFF;
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (3,83,'반짝반짝 나만의 유리 썬캐쳐 만들기',3,to_date('20/01/01','RR/MM/DD'),to_date('20/02/24','RR/MM/DD'),'3.5',55000,'제주특별자치도 제주시 구좌읍 월정1길 47-1','색색의 유리를 원하는 도형으로 하나하나 조각내어 납선을 이용해 하나의 형태로 만드는 작업입니다.
유리썬캐쳐는 조명, 빛에 따라 느낌이 변해요.
그래서 더 매력적인 스테인드글라스 썬캐쳐입니다.

동백꽃,고양이,조개,고래,벚꽃 썬캐쳐 만들기
1.도안 선택(10x10이하로 작업합니다)
2.유리 고르기
도안 선택 후 내 공간과 어울리는 유리를 찾아주세요
무늬도 색도 모두 다 달라서 나만의 유리를 찾는 재미도 쏠쏠해요^^
3.재료, 도구 설명
4.도구사용해보기
유리칼과 유리컷팅도구를 이용해 유리 자르는 연습을 해봅니다.
유리칼 잡는 방법부터 자세히 알려드리니 걱정마세요~
기본 직선, 곡선 자르는 연습을 합니다. 
유리칼이 익숙해지실때까지 자유롭게 연습하실 수 있도록 연습용 유리를 준비해드려요~
5.유리 자르기/동테이프감기/납땜/세척
준비가 되셨다면 이전단계에 선택하신 유리를 도안대로 잘라줍니다.
최대한 밑그림에 가깝게 잘라주셔야 다음작업이 수월해요^^
자른 유리들은 사포, 글라인더를 이용해 다듬어 준 뒤 깨끗하게 닦은 후 동테이프 작업을 합니다.
동테이프를 잘 감아준 뒤 유리조각들을 연결해주기위해 납땜작업을 합니다.

(섬세하고 손이 많이 가는 작업입니다~ 하나하나 자세히 설명해드리니 걱정마세요^^)

인두기가 매우 뜨거우니 작업시 주의해주세요! 납땜후엔 전용 세척용액을 이용해 깨끗하게 세척해줍니다~!
마지막에 모빌 선을 연결하면 작업 끝! 구슬,종,반짝이는 보석등 다양한 아이템들도 준비되어있으니 개인취향에 따라 자유롭게 썬캐쳐를 꾸며가셔도 되세요^^ 

(작업시엔 앞치마,장갑,마스크를 꼭 착용해주세요! 유리가루도 많이 날
리고 유리가 깨질 수 있으니 매순간 조심조심 작업해주세요)','승인완료','KEB하나',110348083,to_date('20/01/01','RR/MM/DD'),58);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (4,87,'공항근처,제주도에서 나만의 은반지Silver Ring만들기',4,to_date('20/01/01','RR/MM/DD'),to_date('20/02/17','RR/MM/DD'),'1.5',50000,'제주특별자치도 제주시 한림읍 월령3길 36','은선을 이용하여 원하는 반지 사이즈에 맞춰 반지를 만드는 작업입니다. 기본 평반지를 만드시는 작업입니다. 다양한 디자인으로 제공하지 못하는 점 양해해주세요! 해당부분은 체험이기 때문에 금속공예 기본기를 알려드리는 체험입니다! 
* 제작과정에서 불을 다루는 작업이 있습니다.
   금속공예의 전과정을 스스로 하셔야합니다!
   체험의 특성상 도움만 드릴거예요:)

* 소요시간은 평균2시간정도 소요됩니다.
   반지를 붙이는 과정은 개인차가 있습니다.
   (2시간 이상 걸리실 수 있어요!)

* 각인
   망치각인(깊은각인, 대소문자, 숫자만 가능)
   기계각인(한글포함 이모티콘도 가능)
   외각/내각 한곳에 가능합니다!

* 해당클래스외의 시간을 원하시는 경우, 메세지를 주세요. (가능한 경우, 원하는 시간에 가능하도록 진행해드릴게요: )

여러분에게 금속공예에 대한 매력을 알게 도와드릴게요
특별한 경험을 원하시는 분들은 참여해주세요: ).','승인완료','새마을금고',221333203,to_date('20/01/01','RR/MM/DD'),112);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (8,46,'함덕해수욕장 옆 서우봉 오름을 걷고 인생사진도 남겨보세요',6,to_date('20/01/01','RR/MM/DD'),to_date('20/02/26','RR/MM/DD'),'1.5',18000,'제주특별자치도 제주시 구좌읍 종달동길 36-10','약속 시간에 함덕서우봉 오름 주차장에 모여서 인원 체크를 하고, 자기소개를 한 후에 간단한 스트레칭으로 몸을 풉니다. 그리고 함덕서우봉 오름으로 올라가면서 이 오름에 대한 대략적인 설명을 합니다. 먼저 정상을 향한 산책로를 걷기 시작하며 일제시대와 제주4.3사건 때 만들어진 진지 동굴도 둘러 봅니다. 함덕서우봉의 수많은 길 중에서 가장 걷기 편한 길로 거닐면서 약 30분이 지나면 첫번째 정상에 오르게 됩니다. 잠시 후 두번째 정상에 오르게 되는데 이곳에서는 제주의 서쪽과 동쪽을 모두 조망할 수 있습니다. 여기서 보는 전망은 이 지역 최고의 뷰라고 자부할 수 있습니다. 이후 산책로를 내려와서 이제는 둘레길을 걷습니다. 이곳은 코발트빛 함덕해수욕장을 곁에 두고 완만한 길을 편하게 걸을 수 있습니다. 주변에는 계절별로 다양한 꽃을 볼 수 있습니다. 봄에는 청보리와 메밀꽃, 여름에는 해바라기, 가을에는 코스모스, 겨울에는 유채꽃을 볼 수 있습니다. 해질 무렵에 걸을 때는 환상적인 석양을 배경으로 다양한 꽃과 함께 인생 사진을 찍을 수 있습니다. 저는 LG 소속작가로 활동하면서 제 스마트폰으로 체험 참가자들에게 무료로 사진도 찍어 드립니다. 스마트폰으로 사진 잘 찍는 팁도 알려 드릴게요. 제주 이주민으로서의 삶과 애환도 말씀드리고, 제주에 대한 모든 것을 알려 드리겠습니다. 전체적으로 총 60분에서 90분 정도 소요될 예정입니다. 함덕서우봉 오름은 대중교통으로도 접근성이 매우 좋아서 자가용이나 렌트카가 없어도, 특별한 준비물 없이도 남녀노소 누구나 오름 트레킹에 참여할 수 있습니다. 서우봉 오름을 걷는 시간은 새벽 6시부터 저녁 7시까지 언제든지 가능하니 정해진 날짜나 시간에 상관하지 말고 문의 주시기 바랍니다. 함덕서우봉 오름 외에 다른 오름도 가이드 가능합니다.','승인완료','외한',342148083,to_date('20/01/01','RR/MM/DD'),74);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (11,45,'사진작가와 함께하는 비밀의 숲 걷기 그리고 인생샷까지',10,to_date('20/01/01','RR/MM/DD'),to_date('20/02/20','RR/MM/DD'),'1.5',30000,'제주특별자치도 제주시 구좌읍 상하도길 44-1','<프로그램 소개>
- 오전 7시 30분 : 미팅 포인트에 집합
- 오전 7시 30분 ~ 7시 40분 : 시작 포인트로 이동
- 오전 7시 40분 ~ 7시 45분 : 간단한 코스 설명 및 주의사항 공지
- 오전 7시 45분 ~ 8시 45분 : 숲길 산책 및 숲 속 설명 그리고 숲 속에서 녹차 시음 
  + 특정 포인트에서 인생샷 한장씩!!
- 8시 45분 ~ 9시 00분 : 시작 포인트로 복귀 및 마무리

 * 본 프로그램을 운영하는 길을 누구보다도 많이 걸었습니다. 걸으면서 혼자서 공부한 내용들이지만 산책길을 걷는데 지루하지 않도록 정보를 제공합니다.
 * 호스트의 직업이 사진 작가인 만큼 잊지 못할 추억을 사진으로 남겨드릴께요!
 * 어떤 날씨에도 걷기 좋은 숲길입니다. 비가 오나 눈이 오나 날씨가 어떻든 걷기 좋습니다.

<Program overview>

 -7:30am: Meeting at the meeting point
 -7:30am-7:40: Move to the starting point
 -7:40 am-7:45: Brief course description and notices
 -7:45 am-8:45 am: Walk in the forest, explanation in the forest and tasting green tea in the forest
+ One shot at a specific point!
 -Return and finish at 8: 45-9:00 start point

I walked more than anyone else on the way to run this program. Although it is a content that was studied alone while walking, it provides information so that you do not get bored walking on the promenade.
 * Because the host''s job is a photographer, I leave unforgettable memories in my photos!
* A forest that is easy to walk in any weather. It walks whatever the weather is raining or snowing.','승인완료','국민',120333232,to_date('20/01/01','RR/MM/DD'),206);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (12,45,'커피를 좋아하는 나와 친구를 위한 셀프 로스팅',4,to_date('20/01/01','RR/MM/DD'),to_date('20/02/28','RR/MM/DD'),'2',40000,'제주특별자치도 서귀포시 성산읍 오조로 75-6','1. 12시와 3시에 하루 두번 시작합니다.
2. 처음에는 핸드드립에 대한 간단한 설명과 도구 등에 설명을 듣습니다. 
3. 먼저 칼리타 드리퍼로 나선형 드립법을 설명 듣고 호스트가 시범을 보고 연습을 한 후 직접 커피를 내립니다. 같은 커피 원두에서 각자 다른 맛을 느끼는 흥미로운 시간이 될 것입니다. 
4. 다음 하리오 드리퍼로 동전형 드립법을 동일하게 체험합니다.
5.나머지 1시간은 약 50그램의 생두를 핸드 로스팅해 봅니다. 커피를 볶으면서 커피의 향기와 커피의 소리를 느끼며 원두로 변하는 과정을 경험할 수 있습니다. 이렇게 직접 로스팅한 커피는 친구를 위해 선물할 수 있습니다.','승인완료','국민',820333232,to_date('20/01/01','RR/MM/DD'),256);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (23,85,'Colorful macrame crafts time with Sunny',3,to_date('20/01/01','RR/MM/DD'),to_date('20/01/23','RR/MM/DD'),'2',35000,'제주특별자치도 제주시 애월읍 고내로13길 83','First, we will introduce each others. and then you will jump into the Macrame handicraft world. I will explain about the history and conception of Macrame shortly. I will show the sample what you will make at the class and you will choose the color of threads. I will prepare a print out for your understanding of macrame. so you don''t need to worry about you forget about the skill after the class:) I will explain step by step with demonstration. and you will follow me. if you have some question, anytime you can ask me and i will help you to make nice macrame stuffs and dream catcher. Everyone will make their own style macrame crafts.','승인완료','기업',920333232,to_date('20/01/01','RR/MM/DD'),30);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (24,83,'눈썰매타고 캠핑피크닉',8,to_date('20/01/01','RR/MM/DD'),to_date('20/01/17','RR/MM/DD'),'4',80000,'제주특별자치도 제주시 용화로 22-1','1100고지 휴게소 앞에서 만납니다-자기소개와 안전사항 전달하고 눈썰매를 나누고 각자 완만한 코스와 오름입구 긴코스에서 눈썰매를 점심시간전까지 탑니다- 점심으로  캠핑요리를 먹습니다-2시전후까지 눈썰매를 탑니다-1100고지 습지를 10분간 걷고 해산합니다','승인완료','새마을금고',220333232,to_date('20/01/01','RR/MM/DD'),208);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (25,82,'컬러테라피 인 제주',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/25','RR/MM/DD'),'2',100000,'제주특별자치도 제주시 구좌읍 월정7길 43-2','제주 여행의 시작.
힐링의 기본 ''나''를 알아가는 시간 먼저 가져보게 됩니다.

빛과 컬러를 통해 나의 마음을 들여다 보고, 
탄생컬러를 통해 현재와 미래의 나를 계획해 보는 시간.

컬러테라피는 나에 대해 집중적으로 들여다보며 이야기를 나눌 예정이에요.
컬러 바틀을 선택하고, 직접 컬러를 나에게 적용해 보면서 내면의 이야기를 들어 봅니다.

-최근 혹은 평소 고민과 주요 심신의 상태를 이야기 해봅니다.
-제주에 오게 된 이유를 나누며 진정한 힐링의 동기를 찾아봅니다.
-개인 고유의 컬러DNA정보와 컬러바틀 선택으로 심신의 상태를 체크합니다.
-컬러메시지를 통하여 나 자신을 돌아보고 앞으로 나아가야 할 방향을 알아봅니다.
-개인 성향에 맞는 여행코스를 계획해 봅니다.


*진정한 힐링 여행을 통해 자아를 더 깊이 이해할 수 있습니다.
*10개월 이상 어린이,청소년들은 인적성 검사가 가능합니다.
*자녀들의 마음 속 이야기를 들어볼 수 있습니다.
*직업을 선택해야 할 때 나만의 인적성을 객관적으로 알아볼 수 있습니다.
*현재의 직업이 나에게 맞는지 알아보고 싶다면 함께 확인해 볼 수 있습니다.
*부부,부모와 자녀, 연인, 친구 등 관계 속에서의 문제를 근본적으로 해결할 수 있습니다.

앞으로 우리가 더 행복한 삶을 살기 위해 나아가야 할 방향을 찾아나가는 시간이에요.','승인완료','외한',320333232,to_date('20/01/01','RR/MM/DD'),278);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (26,44,'제주도에서 나만의 추억 저장? 젤캔들, 무드등 만들기체험',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/16','RR/MM/DD'),'2',50000,'제주특별자치도 제주시 우도면 우도해안길 920','정해진수업시간이 없어 시간조율이 용이한편입니다. 약속한 시간에 공방에 방문하시면 준비되어있는 각가지 재료들을 보시게돼요. 나만의 스타일로 힐링이되는 향을 선택해 컬러를 넣고 추억을 저장해보세요. 여행도중 추억이되는 작은 소품사용도 가능하니 기억해두었다가 챙겨오셔도됩니다.','승인완료','국민',420333232,to_date('20/01/01','RR/MM/DD'),340);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (29,42,'제주의 자연에서 인생사진 만들기',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/15','RR/MM/DD'),'3',47500,'제주특별자치도 제주시 구좌읍 상하도길 46-12','저는 제가 제주도에 거주하면서 느꼈던 아름다운 장소들을 위주로 촬영을 진행할 것입니다. 시간은 오후 3시부터 6시까지 3시간 정도 진행이 되고 평대해변 공용주차장에서 만나서 시작하며 촬영 종료후 해산하는 장소도 같은 장소입니다. 촬영 장소는 2군데~3군데 정도로 이동하며 촬영을 진행을 합니다. 촬영 장소로 이동하는 수단의 저의 자동차로 이동을 할 것이며 촬영하는 카메라는 저의 카메라를 메인으로 활용을 하고 게스트 분들의 휴대폰이나 개인 소지의 카메라 있으면 그것도 활용해서 촬영이 가능합니다. 그리고 촬영 중간중간 사진촬영이나 보정에 관해서 질문사항이 있으면 그때그때 응대해서 제가 아는 범위안에서 알려드리겠습니다.','승인완료','기업',120333239,to_date('20/01/01','RR/MM/DD'),137);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (30,46,'제주에서 아이와 함께 캔들체험하기',6,to_date('20/01/01','RR/MM/DD'),to_date('20/01/17','RR/MM/DD'),'1',15000,'제주특별자치도 제주시 중앙로5길 13','키즈체험클래스로 구성된 프로그램입니다.
아이들이 직접 향과 색을 골라 초를 만들고 포장까지 완벽하게 해볼수 있는 체험입니다

[비즈시트왁스 2개 +티라이트캔들 4개]

1.천연비즈시트왁스
   밀랍으로 만드는 초로 은은한 꿀향이 퍼지며 음이온 발생으로 공기정화및 
   비염에 효과적인  천연소재입니다.
   김밥을 말듯이 돌돌 말아서 만드는 기법으로 5세정도 아이들부터 
   체험가능합니다. 

2.티라이트캔들
   티라이트 용기안에 원하는 향과 색을 골라 직접 만들어봅니다.
   천연소이왁스 또는 팜왁스를 이용해 각각 개성에 맞게 체험할수 있어요

[주의사항]
5세부터 체험은 가능하나
왁스의 온도가 높은편이므로 제작시 주의사항을 꼭 숙지해주셔야합니다','승인완료','새마을금고',120333238,to_date('20/01/01','RR/MM/DD'),24);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (1,42,'제주도 오름 투어와 야경 스냅촬영',7,to_date('20/01/01','RR/MM/DD'),to_date('20/02/25','RR/MM/DD'),'2.5',30000,'제주특별자치도 서귀포시 남원읍 중산간동로 5756','출발 하기전 구름 사진을 보고, 별이 가장 많이 보일곳으로 갈거에요. 

날이 좋아 별이 보이는 날엔 오름에 올라 야경도 보고, 
별이 잘 보이는 날엔 잠시 누워 하늘을 보고 별자리도 알려드릴거에요~ 
또한, 핸드폰으로 별 사진을 찍는 법을 가르쳐 드리고, 함께 찍어보고 있어요.
멋진 음악이 함께한다면 꿈만 같은 제주도의 푸른밤을 만끽 할 수 있을거에요.

별과 야경으로 감성 충전후에는 스냅 촬영 포인트로 이동하여 
조명 설치 후 인생샷이 될만한 스냅촬영을 할 거에요~ ^^','승인완료','국민',170349084,to_date('20/01/02','RR/MM/DD'),170);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (2,42,'제주도 푸름밤 사진가와함께 별구경하기',6,to_date('20/01/01','RR/MM/DD'),to_date('20/02/01','RR/MM/DD'),'1.5',15000,'제주특별자치도 서귀포시 안덕면 덕수회관로61번길 1','집결지에 모인후 간단한 길안내와 소요시간을 안내드립니다.
총 4~6명정도의 인원이 저의 차를 타고 가까운 오름으로 이동하며
이동 후 15분정도 트래킹하여 오름을 올라가게 되요.
올라가시면 아름다운 제주의 밤하늘을 즐기시고 사진촬영을 진행합니다.
밤에 이동하기때문에 인솔자를 잘 따라 주셔야 하며, 프로그램이 끝난 후 
다시 집결지로 모셔다 드립니다!
-우천이나 기상악화시 취소됩니다.','승인완료','국민',120333237,to_date('20/01/01','RR/MM/DD'),237);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (5,62,'제주도의 감성을 오롯이 느낄 수 있는 히든스팟에서의 스냅촬영',8,to_date('20/01/01','RR/MM/DD'),to_date('20/02/17','RR/MM/DD'),'1.5',40000,'제주특별자치도 제주시 한림읍 협재1길 19-8','::작가 포트폴리오::
www.instagram.com/hwajeondong 


 신양섭지해수욕장주차장에서 만나서 간단한 미팅 겸 지역소개에 대해  설명한 후 신양섭지해수욕장에서 촬영하면서 알게된 저 만의 촬영스팟과 촬영구도로 언덕길, 모래해변, 돌해변 등을 같이 걸어 다니면서 자연스러운 여행추억을 촬영을 해드릴 거예요.  만나는 장소는 비가 오거나 바람이 많이 불거나 당일 기상상태에 따라 목장분위기의 아부오름이나 히든스팟 숲 또는 시즌에 맞는 유채꽃밭, 억새밭으로 장소변경될 수 있습니다. 타 팀포함 총 참여인원 3인이하는 1시간촬영진행하고 4인이상은 1시간30분 촬영진행합니다. 

 예약시 신양섭지해수욕장이외에도  아부오름이나 봄날의 유채꽃, 가을 날의 억새길 배경으로 이동해서 트립진행합니다. 예약시 문의주세요.

 촬영 전에는 휴대폰으로 기본포즈팁과 다리가 길게 촬영하는 팁등 사진을 잘 찍는 법에 대해서도 알려드릴 거예요.
 또한, DSLR이나 미러리스등 카메라를 가져오시면 카메라강의와 실제 포토그래퍼가 실전에서 사용하는 세팅방법에 대해서도 강의해 드립니다. 카메라에 대해 관심이 많으시거나 사진을 좋아하시는 분은 정보도 공유하고 제주도의 출사장소에 대해서도 얘기나누어보아요. 카메라 강의는 단체예약을 신청하시거나 같이 하시는 팀이 없을 경우이며 같이 하시는 팀이 있을 경우에는 카메라강의 진행이 어려울 수도 있습니다.

 최대한 단독촬영으로 진행해드리기 위해 만약 해당일에 시간이 비는 시간이 있으면 사전에 연락드려 시간변경이 되시는 분이 계시다면 시간 분배해서 최대한 단독촬영으로 진행해 드리려고 합니다.
 사전 단독촬영예약을 원하시는 게스트님은 문의주세요.

 지정장소이외 지역에서의 촬영은 거리에 따라 추가금이 발생할 수 있습니다. 다른 지역의 촬영을 원하실 경우에는 문의주세요.

 사진은 200장~300내외로 촬영해드리며 전체원본은 15일정도 후에 발송되며 보정하시길 원하시는 사진을 다시 보내주시면 보정해서 약 15일정도 후 메일로 발송해드립니다.','승인완료','기업',120333236,to_date('20/01/01','RR/MM/DD'),76);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (6,83,'해녀와 함께하는 특별한 식사 해녀의부엌',8,to_date('20/01/01','RR/MM/DD'),to_date('20/03/01','RR/MM/DD'),'1.5',49000,'제주특별자치도 서귀포시 법환상로2번길 89','해녀의부엌은 우도와 성산일출봉이 보이는 바다 바로 앞에 위치하고 있습니다.

이 공간은,

20여년 전 생선을 경매하는 활선어 위판장으로 지어졌습니다.

판매 비활성화로 인해 위판장은 문을 닫았고 어둡고 인적이 드문 창고로 변했습니다.

시간이 멈춰버린 이 공간에 생명을 불어넣어 국내 최초 "제주 해녀 다이닝"으로 재탄생 시켰습니다.','승인완료','KEB하나',120333235,to_date('20/01/01','RR/MM/DD'),258);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (7,82,'제주밤하늘의 별을 보면서 모닥불과 캠핑바베큐를 즐기는 제주캠핑체험',8,to_date('20/01/01','RR/MM/DD'),to_date('20/02/24','RR/MM/DD'),'4.5',90000,'제주특별자치도 제주시 애월읍 애월해안로 910','뒤로는 산방산과 현무암 절벽과 앞으로는 형제섬을 비롯해 마라도와 송악산 이 보입니다.
넓은 해변에 마치 도로와 가까운데도 무인도와 같은 오지의 느낌을 주는 장소입니다.','승인완료','KEB하나',120333234,to_date('20/01/01','RR/MM/DD'),78);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (9,83,'오름의 여왕 다랑쉬오름 얼리버드 새벽 트래킹과 사진팁',8,to_date('20/01/01','RR/MM/DD'),to_date('20/02/23','RR/MM/DD'),'2',30000,'제주특별자치도 서귀포시 표선면 표선중앙로 73-9','다랑쉬오름 얼리버드 새벽트래킹의 기획의도는 동이 트기 전의 어두움에서 미지의 장소로 산행을 하는 첫 발자국의 설렘과 기대감에서 부터 시작하고 오르는 중간에 쉬면서 또는 걷다가 조금은 가빠 오는 숨을 몰아 쉬며 잠시 동쪽하늘의 변화에 다시 한번 목표를 위해 힘을 얻고 정상에 올라섰을 때 그 어떤 누구보다도 이르게 누구보다도 높은 곳에 올라 내려다보는 자신의 특별함, 자존감과 폐 속에 들어오는 시릴정도의 찬공기의 청량감과 잡생각에 대한 비움을 또한 하산하며 느껴지는 아쉬움을 느끼기 위해 시작하였습니다.

 동이 터오르기 전 다랑쉬오름 주차장에서 만나 별들과 함께 서로의 소개시간과 지역소개, 다랑쉬오름소개시간을 가진 후 정상으로 트래킹을 시작합니다. 때때로 별똥별을 보는 행운도 만나실 수 있을거예요.  다랑쉬오름은 제주도 동쪽에서 두번째로 높은 오름으로 살짝 가파른 구간도 있지만 20분정도면 정상에 오를 수 있습니다.  

 정상에 올라가며 제주사람들의 사는 이야기, 주변의 오름인 아끈다랑쉬오름, 용눈이오름, 손지오름등에 대해 이야기 나눌 거예요. 
 포토그래퍼들의 일출 촬영포인트로 가서 해가 떠오르기 전의 여명과 해오름을 감상하며 가지고 계신 휴대폰으로 구도 잡는 법, 사진 잘 찍히고 잘찍는 법등을 가르쳐 드릴 거예요. 
 해가 보이지 않은 흐린 날에도 찬란한 해가 떠오르는 풍경과는 다르게 진하고 먹먹한 느낌으로 다가오는 감성을 느끼게 되실거예요. 비가 오는 날 진짜 운이 좋다면 환상적인 운해를 감상하실 수도 있어요.
 DSLR이나 미러리스 카메라를 가져오신 분들은 카메라 작동과 실전 포토그래퍼들이 사용하는 세팅에 대해서 카메라를 가져오지 않으신 분들에게 최대한 피해가 가지 않을 정도의 간단한 팁을 가르쳐드릴꺼예요.
 삼각대를 준비하시면 하이퍼랩스로 더욱 멋진 영상을 촬영하실 수 있으세요.

 해가 완전히 올라온 후에는 다랑쉬오름의 분화구 둘레를 같이 걸으며 한라산쪽으로 펼쳐지는 오름군락과 북쪽의 평야를 감상할 예정이며 2시간 정도 진행할 예정이고 하산 후 오름등반과 촬영 소감에 대해 나눔의 시간을 가질 예정입니다. 

 모이는 시간 예상시간은 해뜨는 시간 30분전(12월 기준 오전 6시30분~7시 예상)이며 해 뜨는 시간이 계절에 따라 다르므로 모이는 시간은 전 날 메세지로 공지해드리고 입니다. 비가 오는 날은 더 재미있고 우천시에도 트립은 진행되며 우의를 제공해드립니다. 한 분만 참석하셔도 투어는 진행되니 부담없이 신청해주세요.','승인완료','외한',120333233,to_date('20/01/01','RR/MM/DD'),292);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (10,46,'마크라메 미니트리 만들기',8,to_date('20/01/01','RR/MM/DD'),to_date('20/02/20','RR/MM/DD'),'1',30000,'제주특별자치도 제주시 한경면 용수2길 24-4','제주공항에서 가까운 곳(차량기준 5-10분)에 위치하고 있어 여행 오신분들께 첫 일정 또는 마지막 일정으로도 괜찮을것 같습니다 :) 인테리어를 마크라메 작품들로 해놓아서 아늑하고 다양한 마크라메 작품들을 감상하실 수 있답니다!','승인완료','KEB하나',120333231,to_date('20/01/01','RR/MM/DD'),174);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (13,83,'제주 돌담풍경을 만들고 나의 손글씨를 써보는 시간',6,to_date('20/01/01','RR/MM/DD'),to_date('20/03/02','RR/MM/DD'),'2',35000,'제주특별자치도 서귀포시 대정읍 상모대서로20번길 31-15','아름다운 제주 돌담길을 떠올려 보세요. 그 중에서 가장 마음에 들었고, 간직하고 싶은 풍경을 우리는 직접 만들게 될거에요.

귤이 주렁주렁한 풍경, 제주돌집, 동백꽃, 바다, 갈매기, 고래 등 무엇이든 좋아요. 제가 드리는 재료로  만들고 색칠하고, 직접 현무암 돌로 작은 돌담도 쌓아보게 될거에요.

원하던 풍경이 나오셨다면, 우리는 그 풍경에 어울리는 글귀를 찾을거에요. 나를 위해, 또는 누군가에게 선물할 글귀를요. 그리고 떨리지만, 천천히 써봅니다. 잘 쓰지 못해도 괜찮아요, 마음을 담는게 중요해요

같이 이야기도 나누면서, 제주의 추억을 함께 나눌 수 있는 시간이길 바래요.
온전히 나에게 집중할 수 있는 특별한 체험이 될거에요.','승인완료','기업',110349082,to_date('20/01/01','RR/MM/DD'),158);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (14,46,'제주 나만의향수만들기',6,to_date('20/01/01','RR/MM/DD'),to_date('20/02/25','RR/MM/DD'),'1',50000,'제주특별자치도 서귀포시 성산읍 오조로70번길 26','최고급 코스메틱원료로 고급스러운 향을 느껴보실 수 있습니다
향수제작과 동일한 조향차트를 작성하고 나에게 맞는 향을 찾아냅니다 탑 ,미들 ,라스트노트 조향원료에서 맞는 향기를 찾아내고 샘플작업후  수정후 본 제품을 만듭니다','승인완료','우체국',110349083,to_date('20/01/01','RR/MM/DD'),325);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (15,83,'제주내음가득요리와 도자기체험 그리고 제주여행의 추억 간직하기',10,to_date('20/01/01','RR/MM/DD'),to_date('20/02/22','RR/MM/DD'),'1.5',55000,'제주특별자치도 서귀포시 안덕면 덕수회관로87번길 34','제주도의 동쪽지역 ‘김녕리 2107 또는 일주동로 2028(신주소)''에 소재한 ‘단송레서피’로  12시(점심클래스) 또는 오후 6시(저녁클래스)에 오셔서 전국생산량의 70%를 차지하는 제주의 대표적 작물인 제주메밀과 한우 그리고  신선한 채소를 주재료로 한 제주메밀소고기전골과  제주흑돼지, 전복과 새우 등을  주재료로 하는 제주흑돼지전복샐러드정식 등 (모든요리 1인분 25,000원 상당, 재료의 신선도와 계절식재료에 따라 메뉴가 변동되는 ''오마카세''방식)을 드신 후 도자기체험을 하실 수 있습니다. 어떤 메뉴이든 MSG없는 건강식 위주로 구성되며 식사 후 차가 제공됩니다. 어른은 물론 유치원이상의 아이들도 함께 참여하실 수 있습니다. 가족단위의 체험도 환영하며 아이들에겐 특별한 추억이 될 것입니다. 식사시간과 도자기체험은  1시간반 정도 걸린다고 보시면 됩니다. 체험방문 횟수에 따라 만드시게 될 그릇의 종류가 달라지게 되며 그 난이도 또한 올라가 오실수록 더욱 재밌는 프로그램을 체험하시게 됩니다.제주에서의 환상적인 여행을 마치신 후 만드신 도자기를 택배편(착불)으로  집에서 받아보실수 있어 여행의 추억을 오랫동안 간직될수 있으며, 물레체험시 촬영한 추억사진을 인화하여  함께 보내드립니다.
또한 주변에 김녕성세기해변, 비자림, 만장굴 등 제주에서 유명한 관광지에 인접해있어 체험후에도 아름다운 경치를 즐기실 수 있는 지리적 장점도 있습니다. 일주동로 상에 위치해 있고 주차공간도 넓어  편리합니다. 마당에 빨간 컨테이너가 있는 노란색 건물을 찾으세요~! 
가족들 또는 친구, 동료들과 함께하는 맛있고 건강한 ''제주내음가득요리와 도자기체험''은 여러분에게 특별한 경험이 될것입니다.','승인완료','우체국',110349084,to_date('20/01/01','RR/MM/DD'),92);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (16,42,'요리책방 감귤서점의 요맛즐 프라이빗 쿠킹 클래스',2,to_date('20/01/01','RR/MM/DD'),to_date('20/01/19','RR/MM/DD'),'2',38000,'제주특별자치도 제주시 한림읍 협재로 8','내 요리의 시작, 여행자들을 위한 쿠킹 클래스.

''감귤서점 쿠킹 클래스''는 요리책이나 요리잡지에 실렸던 인기 레시피를 제주재료를 가지고, 그대로 만들고 맛보고 즐기는 체험 프로그램입니다. 쿠킹 가이드의 전체적인 설명과 요리 과정과정에서 알려드리는 꿀팁을 통해 요리에 대한 배움과 즐거움을 갖게 될 겁니다.

♥ 감귤서점은 매주 화, 수 휴무이며 오전 10시반~오후 5시반까지 문을 엽니다.

쿠킹클래스는 월, 금, 토, 일요일에만 열립니다. 신청 날짜가 보이지 않는다면 이미 신청한 분이 있는 것입니다.

♥ 신청하시면, 
시간, 장소, 메뉴 등에 대한 안내 문자를 드립니다. 

메뉴는 1인당 1가지를 만듭니다. 첫 참여자는 위한 시그니처 메뉴도 선택 가능하며, 계절별 메뉴도 선택 가능합니다. (2가지 메뉴를 만들어보고 싶다면, 2인으로 신청하고 2가지 메뉴를 고르시면 됩니다.)

첫 참여자를 위한 시그니처 메뉴
- 감귤소스를 곁들인 구운 감귤과 제주돼지 폭찹스테이크
- 제주당근 듬뿍 크림 파스타
- 제주 청정닭과 표고버섯으로 만든 발사믹소스 닭고기버섯덮밥

12~1월 겨울 메뉴
- 제주 흑돼지와 채소를 넣어 만든 따끈한 흑돼지 스튜
- 제주 딱새우살로 만든 딱새우 투움바 파스타

이전 참여로 모든 메뉴를 체험하셨다면? 게스트님에게 맞춰 다른 메뉴를 제안드려요!

♥ 트립날! 
1시간반~2시간(설명+실습+시식+뒷정리) 정도 소요됩니다. 

1. ''감귤서점''의 작은 원목키친에서 1~3인이 요리합니다. (1인 신청시 다른 신청자 1~2명과 함께 요리할 수 있습니다. 단체는 4인까지 신청 가능하니, 사전에 문의 문자를 보내주세요.)

2. 10분 전에 도착해 손도 씻고, 앞치마도 입어야 해요.

3. 테이블에는 레시피와 재료가 준비되어 있어요.

♥ 요리 시작
메뉴, 재료, 조리법 등에 대한 설명을 듣고 레시피 그대로 따라 하며 요리를 만들게 됩니다.  플레이팅팁도 알려드려요. 실제 요리책 촬영에 사용했던 그릇들 중 원하는 것을 골라 나만의 플레이팅을 완성하세요.

♥ 식사 타임
이제 즐겁게 식사하세요.

♥ 뒷정리
다음 클래스를 위해 설거지 및 뒷정리를 해주세요.

♥레시피A/S
레시피를 드리는데요, 모르는 것이 있다면 레시피팩토리 네이버 독자카페 Q/A 게시판에 올려주세요. 빠르게 답변 드릴게요!','승인완료','국민',110349085,to_date('20/01/01','RR/MM/DD'),53);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (17,85,'100년된 제주전통흙집에서 흙으로 만드는 예술소품',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/24','RR/MM/DD'),'2',45000,'제주특별자치도 제주시 제원길 16','1. 컵 만들기 
    판성형 기법( 밀대로 밀어서) 또는 코일링 기법으로 원하는 모양의 컵을 만든 후 그림이나 색칠, 이니셜도장등으로 마무리 하고 한달에서 길게는 두달후 구어서 택배로 받아보실 수 있어요~(무료배송)

2. 접시 만들기
    판성형 기법(밀대로 밀어서)으로 준비된 틀을 이용해 제작 후 그림이나 색칠, 이니셜도장등으로 마무리 하고 한달에서 길게는 두달 후 구어서 택배로 받아보실 수 있어요~(무료배송)

3. 조명, 풍경(종)
    판성형 기법(밀대로 밀어서)으로 원기둥 형태의 모양을 만든 후 천공기로 자유롭게 타공 하거나, 자신의 별자리로 타공하여 구멍을 통해 빛이  세어 나오게 하는 방식의  조명으로 사용합니다. 한달에서 길게는 두달 후 구어서 택배로 받아 보실 수 있어요~ (무료배송)

4. 기타등등 
   의논해요~ ^^','승인완료','새마을금고',170349085,to_date('20/01/02','RR/MM/DD'),230);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (18,21,'제주에서 사진작가와 함께 배우고 담아내는 스냅촬영 snapshot',6,to_date('20/01/01','RR/MM/DD'),to_date('20/01/21','RR/MM/DD'),'1.5',40000,'제주특별자치도 제주시 구좌읍 동복로2길 12','*약속장소에서 만나면 간단한 오리엔테이션을 진행한 후 체험이 시작됩니다.

*주요 체험장소는 제주 서쪽 ‘협재해수욕장’ 인근 이에요. 협재에서 금능까지 멀지 않은 길을 자유롭게 산책하며, 작가가 촬영하면서 알게된 특별한 장소에서 1시간 30분간 스냅촬영을 진행합니다.


*체험이 끝나면, 한 팀당 제가 DSLR로 촬영한 원본사진 300여장을 전달해 드릴거에요. 그 중에서 마음에 드는 A컷 사진을 15장 이내로 선택하시면 다시 작가의 색감으로 작업해서 드립니다.

*촬영된 사진은 이메일 혹은 구글 드라이브, 네이버 클라우드 등 전달받기 편하신 방법으로 전달해 드리겠습니다.


*카메라를 가져 오신다면 사용방법에 대해서도 간단히 안내해 드려요. DSLR, 미러리스, 필름카메라, 핸드폰 카메라까지. 어떤 형태의 카메라를 가지고 오셔도 좋습니다.

*매일 달라지는 야외날씨에 맞게 전문적인 카메라 세팅값과 핸드폰 APP을 활용해 직접 찍은 사진을 쉬우면서도 풍부하게 표현하는 방법을 알려드릴게요.


*날씨상황이 좋지 않을 때에는 해변이 아닌 작가의 또다른 추천 장소로 변경될 수 있어요, 예약하신 게스트 분들에게 사전안내 드리겠습니다.

*함께 오신 일행분들에게 조금 더 집중할 수 있게, 되도록이면 한 타임에 한 팀씩 진행하려고 합니다. 


tip. 협재는 제주 서쪽에 위치하고 있어서 날이 맑은 날엔 일몰과 함께 하기를 추천드립니다. 마지막 체험 시간은 계절별로 일몰시간에 맞춰 변경됩니다.','승인완료','기업',110349086,to_date('20/01/01','RR/MM/DD'),85);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (19,45,'손의 모험 가죽공예 여권케이스 , 베루카드명함 지갑 만들기',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/18','RR/MM/DD'),'2',65000,'제주특별자치도 제주시 구좌읍 상하도길 44-1','제주 국제공항에서 서쪽으로 오면서 아름다운 제주 바다를 바라보다 보면 어느덧 Handsworks  Atelier 에 도착합니다. 검정색 테두리의 유리문을 열고 들어서면 가죽냄새가 여러분을 반겨줄거에요.

수공예 가죽가방, 지갑, 액세서리 등등을 잠시 구경하고 서로 소개를 하며, 저의 이야기와 제주도에서 가죽공방을 하는 이유를 들려드릴게요. 재미있는 가죽이야기, 오늘 사용하는 모든 재료와 도구, 가죽과 도구를 살 수 있는 장소도 알려드립니다. 

제주도는 친환경 지역입니다. 조금이라도 제주 환경에 도움이 되려고 다음과 같은 재료를 사용해요.

#가죽  - 친환경 베지터블 가죽 (가공방식 ~ 나무껍질의 탄닌 성분으로 가죽염색)
#실 - 프랑스 린넨 실 
#접착제 - 이태리 수용성 접착제 (냄새가 나지 않습니다)

여권케이스, 카드명함지갑 - 2가지 품목 중에서 한가지 선택해주세요.  사진 속 가죽색깔 중 한 가지를 미리 선택하셔야 해요.
(2명 예약시 1명은 여권케이스, 1명은 카드명함지갑 선택해도 되고, 2명 같은것 선택해도 됩니다)

아래 작업 순서를 참고해주세요.

원활한 진행을 위해 제가 미리 가죽을 재단해 놓습니다.
게스트는  재단된 가죽에 가죽로션을 바르고, 바느질할 부분에 크리져로 선을 표시한 후 그리프(치즐)로 망치질을 해서 바느질 구멍을 뚫습니다. 그런 다음  친환경접착제로 가죽을 붙이고 바늘 2개(새들스티치)를 이용해서 손바느질을 합니다.

새들스티치(Saddle Stitch) - 왁스를 입힌 프랑스산 린넨 실을 바늘 2개에 연결합니다. 왼손, 오른손에 바늘을 한 개씩 잡고, 미리 뚫어 놓은 가죽에 한 번씩 넣어줍니다. 두 번 바느질한 효과가 나서 하나의 스티치가 끊어지더라도 다른 하나의 스티치가 남아 있기 때문에 튼튼한 제품이 됩니다.

포니 - 양손을 사용하는 손바느질을 할때 가죽을 잡아 줍니다.

바느질을 하다 보면 어느덧 완성되어 있는 카드, 명함지갑을 만나게 됩니다.
물론 지폐도 접어서 넣을 수 있어요.','승인완료','외한',110349087,to_date('20/01/01','RR/MM/DD'),206);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (20,63,'전문 사진가와 함께하는 석양의 매직아워 제주도 새별오름',6,to_date('20/01/01','RR/MM/DD'),to_date('20/01/15','RR/MM/DD'),'1.5',40000,'제주특별자치도 서귀포시 성산읍 서성일로1222번길 17','해가 지기 1시간 전에 새별오름 주차장에서 만날 거에요. (12월 기준 오후 4시) 잠시 인사 나눈 뒤 서쪽 능사면으로 올라가면서 제주살이에 대해 이야기 해 드릴게요. 경사로가 끝나면 평지같은 구간이 나타나는데 거기서 부터는 제가 바쁘게 뛰어다니며 사진을 찍어드릴 거에요. 새별오름은 지는 해를 배경으로 뷰가 정말 끝내주거든요. 정상에 오르면 새별오름을 둘러싸고 있는 오름들에 대해서도 설명해 드릴게요. 날씨가 맑던 구름끼던 비가 내리던 각양 각색의 아름다운 매력이 있는 곳이에요. 정상에서 기념촬영 후에 잠시 인파를 벗어나 고즈넉한 길을 걸을 거에요. 발길이 멈추는 곳, 붉게 물든 오솔기에서 감동적인 석양을 감상하며 매직아워에 대한 이야기를 해드릴게요. 

1시간30분이면 모든 체험이 종료될 거에요. 사진들은 열장 내외로 제가 골라 이메일이나 카카오톡으로 보내드릴게요. 제주에서 건져가는 최고의 수확물이 되길 바라요.','승인완료','우체국',110349088,to_date('20/01/01','RR/MM/DD'),210);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (21,86,'제주 여행을 기억하다 _ 에코백 핸드 프린팅 원데이 클래스',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/16','RR/MM/DD'),'3',50000,'제주특별자치도 서귀포시 대정읍 하모상가로 35-5','****제주 여행 사진만 진행하니 확인하시고 신청해주세요~ ****
****어른들을 위한 힐링 핸드페인팅*** *  
****19FW 부터 린넨 에코백으로 변경 됩니다*** ** 회색은 남은 재고 소진시 까지 ****
***에어비앤비에 숙소를 운영하고 있어서 수업 시간이 날짜마다  달라요 ~~양해 부탁드려요 ***

제주여행을 기억하다 _  only one ,  only for you 
매번 와도 다른 느낌의 제주,  
그날 , 그 시간 , 그 장소에서의 그 기억을
항상 사용할수 있는 에코백에 담아가세요

수업전 사전 작업  *필독*
제주 여행 사진을 선택하여  하루전날 오전중까지 보내주시면
일러스트 작업하여   당일 그릴수 있게 A4용지에 출력해서 준비해 드립니다

(*일러스트 작업: 컴퓨터 일러스트프로그램으로  선 하나하나 라인을 그리는 작업으로
   한장의 사진당 1시간반~ 2시간 소요 되므로  사전에 꼭 보내주세요. 
   이렇게 작업해서 only one, only for you 에코백이 시작 됩니다)


클래스 방문후
사전 준비된 일러스트 라인 따라 에코백위에  밑그림 그린후  (카본지 먹지 활용)
검정색 밑그림위에  아크릴펜으로 그림 그리기 시작하면 됩니다. (아크릴펜 및 패브릭 물감은 준비되어있어요 )
선이 많을수록 시간이 많이 걸리며
2번이상은 같은 라인을 덧 칠해야 원하는 색상이 나오므로 시간 넉넉히 생각하고 오세요

**밑그림 따라 계속 그리기 때문에 누구나 가능하지만
   완성도 있는 제품으로 마무리 하기까지는 행복한 반복 작업이 있습니다~
   언제 이렇게 아무생각없이 ,  그것도 바다 보면서  집중할수 있나 하시면 힐링이 되실겁니다~~**

라인 작업후 부분적으로 채색이나 패턴을 넣거나
이니셜, 좋아하는 문구를 넣으면
아트적인 느낌이 나는 나만의 데일리 에코백이 완성 됩니다.

아크릴펜으로 유명한 독일의 아크릴펜 사용
원단이 톡톡한 자연주의 소재인 린네 에코백 사용
****제품같은 완성도를 위해 좋은 재료 준비했으니 마감을 꼼꼼하게 해서 가세요****

음료제공 정성가득~
스페셜티커피브랜드  핸드드립커피 
프리미엄 영국  Brew Tea  Co.
천연재료 이태리 La via del Te''
그리고
카페에서 만드는 천연발효종빵','승인완료','기업',110349089,to_date('20/01/01','RR/MM/DD'),281);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (22,42,'현대미술을 통해 위로하는 새로운 제주',5,to_date('20/01/01','RR/MM/DD'),to_date('20/01/19','RR/MM/DD'),'1.5',10000,'제주특별자치도 서귀포시 중문로105번길 12','공항 주변에 위치한 개인 작업실에서의 모임입니다. 1. ''개나소나하는 현대미술'' 이라는 강의를 들으시게 됩니다. 2. 작업실의 전시 공간에 ‘contemporaty Jeju ''를 주제로 한 개인 작품을 도슨트 형식으로 설명하고 자유롭게 질문을 받는 시간을 같게 됩니다. 3.작가의 캠페인 ''제주 인스턴트''를 수체화로 체험하는 시간을 갖습니다. 체험은 알기 쉽고 재미있는 현대미술의 접근법이 될것입니다. 한사람 한사람 제주를 추억하고 시간이 지난뒤 기억할수 있는 경험이 되기를 희망합니다.','승인완료','KEB하나',110349080,to_date('20/01/01','RR/MM/DD'),87);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (27,42,'사진가와 함께 하는 제주바다산책',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/27','RR/MM/DD'),'1.5',37500,'제주특별자치도 제주시 중앙로1길 41-1','광활하게 펼쳐진 표선 해비치 해변에서 시작으로 올레3코스를 거슬러, 관광객에게는 잘 알려지지 않은 소금막해변까지 천천히 거닐겁니다. 몇 년전에는 바닷길로만 되어 있던 올레 3코스의 마지막 부분에 걷기 편하도록 오솔길을 만들어 놓아 산책하기 그만이지요.
걸으면서 펼쳐지는 제주만의 색감을 가진 풍경을 배경으로 자연스럽게 촬영을 할 겁니다.
쉬어 가기도 하고, 제주여행을 주제로 이야기도 나눌거예요. 힘들기 시작할 즈음 나오는 언덕에서 바라보는 풍경은 멀리 영국의 한 해변의 풍경을 닮기도 했습니다. 그 곳에서 촬영을 마무리합니다.

여행 후 보내드리는 사진을 보며 다시 한번 여행의 설렘과 즐거움을 느껴보세요.','승인완료','외한',130349081,to_date('20/01/01','RR/MM/DD'),187);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (28,82,'인생화보집 촬영',5,to_date('20/01/01','RR/MM/DD'),to_date('20/01/23','RR/MM/DD'),'1',40000,'제주특별자치도 제주시 한림읍 한림로 349-5','제가 살고 있는 서귀포 중문에는 관광단지가 있습니다. 잘 알려진 곳임에도 불구하고 사람들의 발길이 많이 닿지 않는 포토스팟에 여러분을 초대하고 싶습니다. 

따사로운 햇살이 내린 잔잔한 바다와 작은 야생화, 억새의 조화. 서울에서 보기 힘든 파아란 하늘까지 함께라면 어디서든 우리는 모델이 될 수 있습니다. 중문 관광단지 내 정원을 거닐다 바다를 배경으로 사진을 찍고, 조금 더 모험을 하실 분은 비밀스런 해변에서 함께 인생샷을 남겨보아요.

체험은 1시간 내외이며, 단독진행을 원하시는 분은 따로 체크한 후 예약해 주시면 됩니다.

장소 변경 등을 원하시거나 색다른 컨셉을 원하시는 분들은 단독 예약을 이용해주세요.','승인완료','외한',130349082,to_date('20/01/01','RR/MM/DD'),45);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (31,86,'서귀포 펍크롤에서 함께 걷고, 이야기하고, 마시며 서귀포의 밤을 느껴보세요!',10,to_date('20/01/01','RR/MM/DD'),to_date('20/01/22','RR/MM/DD'),'3',40000,'제주특별자치도 제주시 구좌읍 면수1길 27','[서귀포 시내]
서귀포 올레 시장 인근의 펍에서 첫 만남이 시작됩니다. 서귀포 시내 중심에 위치한 제주 수제 맥주 펍에서 입장 및 음료 제공 체크가 가능한 팔찌를 제공드립니다. 팔찌를 활용해 음료를 드시면서 새로 도착하는 다른 펍크롤러 분들과 첫 인사를 나눠주세요. 매 2-30분 후 다음 펍으로 이동합니다. 올레 시장을 관통하며 다음 장소로 이동합니다.

[이중섭 거리 - 송동산 인근]
첫 장소인 올레 시장에서 독특한 3개의 펍이 위치한  이중섭 거리로 이동하면서 서귀포의 다양한 먹거리를 구경하실 수 있습니다. 2번째부터 4번째 펍에서 다양한 음료를 즐기면서 펍크롤러 분들과 친해지는 시간을 가져보세요. 첫번째 두번째, 보통 세번째 잔부터 다들 많이 친해지곤 합니다! 이중섭 거리는 한국에서 매우 유명한 예술 거리입니다. 아름다운 경치의 거리에서 함께 걸으며 서귀포의 밤을 느껴보세요. 마지막 펍은 솔동산 거리에 위치한 플레이펍입니다. 플레이펍 도착 전 게임 이벤트가 있으니 바짝 긴장하셔야 할거에요! 펍크롤러들과 함께 팀대항 게임이 진행됩니다 :) 플레이펍에서 다트, 플립 컵 등 다양한 게임을 즐기시면서 못다한 이야기를 나눠보세요. 

서귀포 펍크롤은 여행객들, 아름다운 서귀포의 밤거리, 그리고 펍 오너 분들과도 만나 이야기를 나눌 수 있는 독특한 경험입니다. 

서귀포의 밤을 보내는 가장 재미난 방법, 서귀포 펍크롤과 함께 최고의 시간을 가져보세요!
매월 마지막 토요일에는 스패셜 파티가 진행되니 궁금하신 분들은 메세지로 문의주세요 :)','승인완료','KEB하나',130349083,to_date('20/01/01','RR/MM/DD'),81);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (32,63,'프렌치감성 빈티지캔들 만들기',6,to_date('20/01/01','RR/MM/DD'),to_date('20/01/22','RR/MM/DD'),'1.5',38000,'제주특별자치도 제주시 한림읍 명랑남길 17','체험시간은 한시간 반정도 소요되며 총 2종류를 만들게됩니다!
A와 B 두가지 체험중 하나를 선택하시면 되세요~

A : [컨테이너캔들 1개 +티라이트 캔들 4개]
B : [비즈왁스 타블렛 2개+ 티라이트 캔들4개]

A : [컨테이너캔들 +티라이트 캔들]
[컨테이너 캔들]
1.컨테이너 용기 안에 심지를 고정
2.향료와 염료 선택
3.왁스에 향료 첨가
4.컨테이너 용기안에 왁스를 붓고 굳고 나면 패키지 완성

[티라이트 캔들]
1.왁스에 색소와 향료 넣기
2.티라이트 용기에 붓고 중앙에 심지 꽃기
3.왁스가 굳으면 패키지 완성


B : [비즈왁스 타블렛 + 티라이트 캔들]
[비즈왁스 타블렛]
1.몰드에 드라이플라워를 이용해 디자인 구상
2.왁스에 색소와 향료 넣기
3.몰드에 왁스를 붓고 구상한대로 디자인하기
4.왁스가 굳으면 패키지 완성

[티라이트 캔들]
1.왁스에 색소와 향료 넣기
2.티라이트 용기에 붓고 중앙에 심지 꽃기
3.왁스가 굳으면 패키지 완성','승인완료','새마을금고',170349086,to_date('20/01/02','RR/MM/DD'),60);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (33,21,'제주감성 가득한 마크라메로 나만의 네트백 만들어보아요',10,to_date('20/01/01','RR/MM/DD'),to_date('20/01/22','RR/MM/DD'),'2.5',50000,'제주특별자치도 제주시 한림읍 한림로 221','[ 1단계 - 재료와 전체적인 과정 소개 ]
만들어지는 과정에 대하여 전체적으로 설명을 듣습니다.

[ 2단계 - 매듭법 배우기 ]
마크라메의 기본 매듭법을 배우고 익힙니다.

[ 3단계 - 가방 몸통 만들기 ]
익힌 매듭법을 토대로 가방의 몸통이 되는 부분을 만듭니다.

[ 4단계 - 어깨끈 만들기 및 마무리 ]
가방 몸통에 어깨끈을 연결하고, 재단하여 마무리합니다.

* 마크라메 가방 만들기에 소요되는 시간은 약 2-3시간 정도이며, 수작업 특성상 개인차가 있을 수 있습니다.
* 어깨끈은 몸 길이에 따라 조절이 가능합니다.

아늑한 공방에서 도란도란 이야기 나누며 나만의 하나뿐인 핸드메이드 작품을 만들어보아요 :)','승인완료','외한',130349084,to_date('20/01/01','RR/MM/DD'),118);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (34,41,'사각거리는 세계연필과 함께하는 제주밤의 필사',5,to_date('20/01/01','RR/MM/DD'),to_date('20/01/28','RR/MM/DD'),'2',20000,'제주특별자치도 제주시 한경면 판포중2길 5','우리는 흑연냄새 가득한 연필가게에서 만납니다.
세계각국의 다양한 연필과 문구를 둘러본 후, 함께 할 테이블에 앉아 오늘밤에 어울리는 차를 마시며 (차 무한제공) 서로 가볍게 인사를 나눕니다. (미소담긴 눈인사면 충분해요!  개인 인적사항 질문은 하지 않을거에요.)

테이블엔 ''필사의 기초''(조경국지음, 유유출판사), 세계 각국의 다양한 연필70자루, 강도가 다른 스테들러 마스 루모그라프 연필12본세트, 지우개, 호스트가 직접 만든 작은 필사노트, 작은원고지, 메모지가 준비되어 있어요.

먼저 자유롭게 평소 필사에 대한 생각과 경험을 이야기 나누어요. 그리고 필사를 쉽고 가볍게 만나게 해 줄 책 필사의기초를 함께 훑어봅니다. 좋은 문장 잘 베껴 쓰는 법이 설명되어 있어요 (우리는 전문가가 아니니 편하게 보아요).

잠깐, 연필을 만나기 전 손목과 손가락 스트레칭을 합니다. 이제 우리는 세계 각국의 연필 70자루, 강도가 다른 연필6본세트를 만나 준비되어 있는 필사노트에 자유롭게 끄적여 본 후 가장 마음에 드는 연필 한자루를 골라 처음필사를 시작해봅니다.

호스트가 직접 만든 작은필사노트는 5칸, 6칸, 유선,무선으로 구성되어있어요. 먼저 5칸에 천천히 가지런한 크기로 반듯하게 오와 열을 적어봅니다. (예쁜 글씨체를 연습하는 것이 아닌 자신의 글씨체를 가다듬는 시간이에요) 그리고 6칸, 유선, 무선에 차례대로 적어보아요.

(옮길 책은 본인이 평소 좋아하는 책도 좋고, 연필가게에 있는 책을 고르셔도되요. 연필가게 옆 여행가게에 있는 다양한 책들을 보셔도 된답니다) 

사각 사각 연필소리에 집중해봅니다. 제주의 밤, 혼자만의 필사 시간을 가져요. (연필과 나의 오롯한 순간) 
그리고 마음에 담고 싶은 문장 하나를 준비된 메모지에 적어요. 반으로 접은 후 한곳에 모아 서로 나누어 가집니다. 자유롭게 받은 문장을 읽어주어요. (서로의 마음을 나누는 작은 글귀 선물이지요)

오늘 함께 보낸 소중한 시간을 나누어봅니다. 작은 메모지에 한문장 소감을 적어보아요.
그리고 마무리!','승인완료','KEB하나',130349085,to_date('20/01/01','RR/MM/DD'),320);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (35,82,'나만의 라탄스탠드조명만들기',6,to_date('20/01/01','RR/MM/DD'),to_date('20/01/18','RR/MM/DD'),'2.5',70000,'제주특별자치도 제주시 조천읍 함덕8길 5','하루애제주에서 새롭게 준비한 "라탄미니스탠드조명”를 소개합니다.
라탄공예를 쉽게 접하실수 있도록 원데이 수업으로 체험해 보실수 있습니다.
라탄 공예는 등나무를 얇게 가공해서 촘촘하게 엮어나가는 방식으로 작은 바구니부터 가구까지 만들 수 있습니다. 
친환경적인 소재로 따뜻한 느낌을 주며 일상 속에서 다양하게 활용 할 수 있는 분야입니다. 
라탄공예는 요즘 인테리어로도 소품으로도 많이 쓰이고 있습니다.
여행지에서 직접 자신만의 스탠드조명을 만들어 보는 것 또한 여행의 즐거움이 아닐까 싶습니다.
수업은 원데이로 진행되고 소요시간은 2시간~2시간30분정도 소요됩니다
처음 접하시는 분들도 편하게 만드실수 있도록 도와드립니다.

[라탄스탠드조명]
단스탠드조명으로 침대나 협탁에 놓으면 좋은 아담한사이즈의 스탠드조명입니다
조명에 라탄을 엮어 더 분위기있고 감성적인 아이템으로 만들어줍니다
전구색의 led전구도 포함되어있습니다

[라탄동백트랩가방] 
라탄과 스트랩원단파우치를 연결하여 만드는 손목스트랩가방입니다.
제공되는 원단중 디자인을 골라주시면 됩니다
라탄으로 가방밑바닥을 만든후 원단과 연결합니다
원단은 화이트배경의 동백과 블랙바탕의 동백원단 2가지중 골라 주심 됩니다

모든수업은 재료가 모두  제공됩니다','승인완료','기업',130349086,to_date('20/01/01','RR/MM/DD'),111);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (36,45,'제주에서 힐링타임 하루애제주에서 라탄공예만들기',6,to_date('20/01/01','RR/MM/DD'),to_date('20/01/24','RR/MM/DD'),'2.5',60000,'제주특별자치도 제주시 용화로10길 14','하루애제주에서 새롭게 준비한 "라탄클래스"를 소개합니다.
라탄공예를 쉽게 접하실수 있도록 원데이 수업으로 체험해 보실수 있습니다.
라탄 공예는 등나무를 얇게 가공해서 촘촘하게 엮어나가는 방식으로 작은 바구니부터 가구까지 만들 수 있습니다. 
친환경적인 소재로 따뜻한 느낌을 주며 일상 속에서 다양하게 활용 할 수 있는 분야입니다. 
라탄공예는 요즘 인테리어로도 소품으로도 많이 쓰이고 있습니다.
여행지에서 직접 자신만의 작품을 만들어 보는 것 또한 여행의 즐거움이 아닐까 싶습니다.
수업은 원데이로 진행되고 소요시간은 2시간에서 2시간30분정도 소요됩니다
처음 접하시는 분들도 편하게 만드실수 있도록 도와드립니다.

[20센치 라탄거울]
거울뒷면까지 라탄으로 만들어 보실수 있는 수업입니다.
나만의 라탄거울을 만들어보세요

[연꽃바구니]
연꽃모양의 바구니로 과일이나 소품을 담을수 있는 활용도 많은 아이템입니다.
모양과 마무리는 조금씩 바꿔서 만들어 보실수 있습니다.

[라탄가방] 
라탄과 스트랩원단파우치를 연결하여 만드는 손목스트랩가방입니다.(추가비용발생)

[라탄스탠드조명]
스탠드조명을 라탄으로 감싸서 더 감성돋는 아이템으로 변신시켜줍니다(추가비용발생)

4가지중 한가지 선택하시면 됩니다
모든수업은 재료가 모두  제공됩니다','승인완료','외한',130349087,to_date('20/01/01','RR/MM/DD'),306);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (37,87,'Farm to Table; Healthy Korean Cooking',3,to_date('20/01/01','RR/MM/DD'),to_date('20/01/16','RR/MM/DD'),'4.5',75000,'제주특별자치도 서귀포시 성산읍 난산로41번길 50-12','Welcome to Yeosu where is widely known for having the best Korean food! :)
Our class Concept is Farm-to-Table, healthy & authentic Korean cooking. 

You will be picked up at Yeosu Expo KTX station in the morning. Then we will head to our farm directly.
You''ll be greeted from our lovely Jindo dog (Korean Traditional dog) ''Yeoreum'' which means ''Summer'' in Korean.

You will harvest fresh seasonal vegetables & fruits with my mom. We will prepare hats, gloves & drinkable water for you which make your harvest experience easier (Please bring comfortable clothes for farming experience). Then we will head to our mom''s place (a bit humble, but lovely local Yeosu house), and will learn how to cook healthy Korean cuisine.

Cooking menu will be various Kimchi, Jangajji (Pickled veggies) &Side dish. Menu will be different depends on what seasonal veggies being grown in our farm. (But if you have any specific cuisine in mind, please let me know in advance.) All trip will be translated to English by me, as my mom speaks Korean.

We are gonna eat meals together what we cook at the class. After the class, you can bring home the food which you made . We are able to drop you to KTX Station again after the class, if you want.

-If you wanna stay more in Yeosu, we can introduce nice bnb. just let us know if needed.
-Price included Pick-up service, transportation during the class/ Snacks & Drinks.','승인완료','기업',130349088,to_date('20/01/01','RR/MM/DD'),330);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (39,45,'펀치니들 소품, 제주 귤 인형을 내 손안에',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/16','RR/MM/DD'),'2',35000,'제주특별자치도 제주시 서광로 278','청소년부터 어른까지 할 수 있는 프로그램이며 제주의 귤 인형을 만들어 봅니다.
입체적인 인형 또는 평면의 마그넷을 만들어요.  표정은 내가 좋아하는 모습으로 표현해봐요.

게스트들이 서로 잠깐 소개하는 시간을 가지고 다과를 즐기며 즐겁게 수다데이트를 하며 진행됩니다.
서로 다른 곳에서 왔지만 "제주"라는 이름으로 한 공간에 모여 이야기꽃을 피울 수 있음에 감사함을 느낍니다.

내 손안에 쏙 들어오는 귤인형을 만들며 행복한 시간을 가져보세요. 마무리까지 도와드리며 펀치니들 하는 방법을 알려드립니다. 작업은 두시간 동안 진행되니 여유를 가지고 방문해주세요!

완성된 인형을 들고 제주 돌담앞에서 ''찰칵'' 사진도 찍어 드릴게요.','승인완료','우체국',130349080,to_date('20/01/01','RR/MM/DD'),56);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (40,63,'하바리움 제주도를 품다',10,to_date('20/01/01','RR/MM/DD'),to_date('20/01/18','RR/MM/DD'),'2',40000,'제주특별자치도 서귀포시 성산읍 서성일로1222번길 17','사전 예약으로 1-2시간예상 
방문하시면  직접 덖음한 꽃차와 함께 ^^ 음료를 
제공합니다 
수업에 필요한 재료 선택하시고 꽃 손질 하고 
직접 용기에 디자인을하고 
마무리합니다 
(재료는 일본에서 수입한 재료로 합니다
프리저버드 .오일 . 용기 )
사진촬영도 하실수있습니다

Http://blog.naver.com/kso0020
Http://Instagram :nokome78','승인완료','외한',140349081,to_date('20/01/01','RR/MM/DD'),210);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (41,83,'제주 숲속 알파카와 함께 하는 힐링 체험',10,to_date('20/01/01','RR/MM/DD'),to_date('20/01/19','RR/MM/DD'),'1',5000,'제주특별자치도 제주시 구좌읍 한동북1길 34-6','체험을 시작하기 전 목장 입구에서 호스트의 간단한 주의사항 안내가 있습니다. 기본적으로는 한국어로 설명하지만 영어권 여행객들에게는 중요한 내용은 영어로 설명을 드립니다. 따라서 본 체험은 한국어를 못하셔도 전혀 상관 없습니다. 이후 목장으로 들어서면 넓은 초원을 뛰노는 알파카들을 만나게 됩니다. 호스트의 알파카들 소개와 함께 먹이주기 체험을 시간 제한없이 마음껏 즐기실 수 있습니다. 알파카들과 함께하신 이후에는 개별적으로 자유롭게 알파카전망대 의자에 앉아 뛰어노는 알파카들과 목장 전경을 바라보며 휴식을 취하시다 목장 내 산책로를 따라 숲속 피톤치드로 힐링하신 다음 출구로 나가시면 알파카 목장 체험이 모두 종료됩니다.','승인완료','우체국',170349087,to_date('20/01/02','RR/MM/DD'),242);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (42,45,'소소한 일상이 특별해지는/ 모먼트 홈카페 레시피 클래스',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/25','RR/MM/DD'),'2',18000,'제주특별자치도 서귀포시 칠십리로 61-1','?호스트가 운영하는 카페 모먼트에서 만나 나만의 홈카페 레시피를 만드는 법에 대해 배워봅니다.  
카페는 좋아하지만 커피는 아메리카노 밖에 몰라도 걱정 마셔요.
다양한 추출도구로 직접 만든 커피를 시음해 보면서 자신의 입맛에 가장 잘 맞는 레시피를 찾을 수 있습니다. 

핸드드립부터 클레버, 프렌치프레스, 모카포트까지 다양한 추출 도구들을 체험해 보며 커피 왕초보도 쉽게 친해질 수 있도록 도와드립니다. 
(모카포트를 이용한 에스프레소와 아메리카노 만들기, 프렌치프레스로 카페라떼 만들기, 클레버를 이용한 브루잉커피 만들기)

카페와 정원의 아름다운 스팟들에서  직접 만든 음료를 즐겨보세요.
피크닉세트와 다양한 소품들이 준비되어 있어 소중한 순간을 아름답게 담아낼 수 있답니다.','승인완료','우체국',140349082,to_date('20/01/01','RR/MM/DD'),190);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (43,21,'<2인가격>제주에서 나와 우리만의 힐링&아쉬탕가요가<1:1/2인/소규모>',1,to_date('20/01/01','RR/MM/DD'),to_date('20/01/24','RR/MM/DD'),'1.5',85000,'제주특별자치도 서귀포시 성산읍 온평포구로54번길 61','### 예약 전에 반드시 아래 내용 확인하세요!! ###
(에어비앤비 시스템상 인원에 따라 가격이 다르게 적용되지않으므로 아래 내용 꼭 확인후 예약 진행 필수~!!)

***수련비 8만5천원은 2인 기준 에어비앤비로 예약시 금액**

"커플,연인,친구,동료 or 개인이 원하는 스타일의 요가수련 프로그램으로  나만의 우리들만의 특별한 힐링과 리트리트"

1. 요가수련 인원 별 금액 및 소요시간

 ***수련비 8만5천원은 2인 기준 에어비앤비로 예약할시 금액***

 <직접 예약> 
   1인 6만원 힐링요가+아쉬탕가 빈야사 요가 도입부 체험(70분)
          7만원 아쉬탕가 빈야사 요가 프라이머리 시리즈(90분)
  2인 8만원(90분)
  3인 9만원(90분)
  *기본 꽃잎차 이외에 카페 음료 더치커피, 청귤청티 제공 **   

2. 요가수련 스타일 선택
   힐링요가
   아쉬탕가 빈야사 요가 프라이머리 시리즈
   * 2인 이상시 기본순서
    명상+힐링요가+기본요가자세(척추, 골반등을 교정하는 자세)+
    아쉬탕가 빈야사 요가 도입부 체험+함께하는요가+마무리자세+휴식

3. 요가수련 장소 선택
  * 별도 문의 없으면 실내 요가룸에서 차분히 진행!!
 실내 : 귤밭이 보이는 조용하고 차분한 요가룸(소규모레슨/3인 이내)
 실외(날씨 상황에 따라 가능 / 사전 문의/ 인원 문의)  
    1) 새소리와 자연을 느낄수있는 귤밭이 보이는 요가룸 마당의 잔디밭
    2) 멀리 바다조망이 보이고 따스한 햇살과 바람을 느낄수있는 요가룸 루프탑
    3) 깊은 자연을 느낄수있는 난대림 금산공원

   * 모든 문의 : 010 9125 7961 *
   * 요가포즈 사진촬영& 발송해드림 *
   * 달력에 나와있는 일정 이외의 일정은 따로 문의 및 조절 가능','승인완료','국민',140349083,to_date('20/01/01','RR/MM/DD'),68);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (44,44,'따뜻한 느낌의 일러스트, 아이패드 원데이 클래스 /무노 테이블 드로잉',3,to_date('20/01/01','RR/MM/DD'),to_date('20/01/15','RR/MM/DD'),'3',47000,'제주특별자치도 제주시 조천읍 신북로 540-3','작은 그림서점 무노 테이블에서 진행되는 이 트립은 2시간 30분 동안 진행됩니다. 

30분 정도 procreate 어플에 대한 기본적인 설명을 듣고 난 후, 1시간은 제주와 관련된 풍경과 사물을 따뜻한 느낌의 일러스트로 표현하는 방법에 대해 듣고, 같이 그려보는 시간을 가집니다.

제주의 돌담, 해변, 귤 외에 제주에서 먹었던 맛있는 먹거리 등 제주와 관련된 것들 몇 가지를 아이패드로 같이 그려본 후에는 나머지 1시간 30분 동안 오롯이 나만의 그림을 그립니다. 어떤 식으로 표현해야할지 어려워하지 않도록 옆에서 가이드를 해드립니다.','승인완료','우체국',140349084,to_date('20/01/01','RR/MM/DD'),105);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (45,83,'제주 방탈출 게임: 더 벙커',3,to_date('20/01/01','RR/MM/DD'),to_date('20/01/16','RR/MM/DD'),'3',30000,'제주특별자치도 제주시 용화로 22-1','Jeju Tourism University. For obvious reasons, the precise location is not shared.

However, the meeting point is:

Room 2104 of the 
Jin''chwi''gwan Building (진취관)
[the building with the outdoor staircase on its east side]
at Jeju Tourism University (제주관광대학교)

The  GPS coordinates are : 33.44702, 126.43465  
put that into g o o g l e maps to get the exact location of the meeting point.','승인완료','우체국',140349085,to_date('20/01/01','RR/MM/DD'),208);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (46,21,'제주감성 가득한 마크라메 플랜트행거 만들기',10,to_date('20/01/01','RR/MM/DD'),to_date('20/01/21','RR/MM/DD'),'1',35000,'제주특별자치도 제주시 애월읍 일주서로 6158','[ 1단계 - 재료와 전체적인 과정 소개 ]
만들어지는 과정에 대하여 전체적으로 설명을 듣습니다.

[ 2단계 - 매듭법 배우기 ]
마크라메의 기본 매듭법을 배우고 익힙니다.

[ 3단계 - 플랜트행거 만들기 ]
익힌 매듭법을 토대로 플랜트행거를 만듭니다.

[ 4단계 - 남은 실 자르기 및 마무리 ]
남은 실을 원하는 길이로 자르고 연출합니다. 

* 마크라메 플랜트행거 만들기에 소요되는 시간은 약 1시간 정도이며, 수작업 특성상 개인차가 있을 수 있습니다.

마크라메 플랜트행거는 인테리어용, 집들이 선물로 아주 좋으며 특별히 손재주가 없더라도 마크라메를 쉽게 접해 보실 수 있을거예요! 
아늑한 공방에서 도란도란 이야기 나누며 나만의 하나뿐인 핸드메이드 작품을 만들어보아요 :)','승인완료','우체국',140349086,to_date('20/01/01','RR/MM/DD'),1);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (47,63,'제주에서의 설렘을 일상으로 - 캔들과 디퓨저 원데이클래스',2,to_date('20/01/01','RR/MM/DD'),to_date('20/01/30','RR/MM/DD'),'3',50000,'제주특별자치도 제주시 한경면 고락로 100','제주바다에서 직접 주워 온 조개껍데기와 곱게 잘 말려진 드라이플라워로 캔들과 디퓨저를 데코하거나 원하는 모양의 캔들을 만들어 볼 수 있는 시간입니다.  약 3시간 동안 진행되며 (유리컵캔들1개+디퓨저1개)(왁스타블렛2개+다퓨저1개)(필라캔들2개+디퓨저1개)  중 선택하여 만들어 보실 수 있습니다. 수업 당일에 오셔서 샘플을 보시고 선택하시면 되니 미리 고민하지 않으셔도 됩니다. 강사는 저 1명이며 기본적인 재료, 도구 설명부터 만들어보기, 포장하기, 사용시 주의사항 등 모든 과정에 참여하시게 됩니다. 수업시간동안 만드신 캔들과 디퓨저는 포장해서 바로 가져가실 수 있습니다. 제주와 여행, 캔들과 향기에 대해 많은 이야기도 함께 나누어보아요.','승인완료','우체국',140349087,to_date('20/01/01','RR/MM/DD'),277);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (48,44,'마음에 평화를 주는 포슬린아트클래스',2,to_date('20/01/01','RR/MM/DD'),to_date('20/01/18','RR/MM/DD'),'2',35000,'제주특별자치도 제주시 우도면 우도해안길 920','워크숍은 프랑스 스타일의 유럽식 2층 건축물 1층 아틀리에에서 진행됩니다.  핸드드립 커피를 비롯한 다양한 음료와 디저트를 주문할 수 있는 갤러리카페에서 다양한 포슬린아트 작품들도 감상하실 수 있어요. 클래식음악과 함께 남동향의 햇살이 가득한 아틀리에세난에서 특별한 포슬린아트 체험을 즐겨보세요.','승인완료','외한',140349088,to_date('20/01/01','RR/MM/DD'),340);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (49,87,'숲에서 걷고 쉬며 힐링하기',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/30','RR/MM/DD'),'3',54000,'제주특별자치도 제주시 구좌읍 구좌로 149-9','우리는 자연에서 어떤 치유를 추구할까요? 우리는 육체적인 피로와 더불어 인간 관계의 어려움으로 인한 피로로부터의 회복을 추구합니다. 
숲속에서 시간을 보내면서 우리는 우리의 마음이 우리의 자연 환경에 의해 부드럽게 누그러지는 것을 느낄 수 있으며, 우리는 이 조용함과 평화로움를 다시 회복할 수 있습니다. 
서귀포의 치유의 숲에 대해 소개 드리면서 좀 더 편안한 마음으로 살아갈 수 있는 건강한 생활방식을 공유하려 합니다. 이 경험을 하는 동안 자연에서 자유롭게 돌아 다니며 숲 산책, 트레킹, 명상, 호흡 등을 통해 일상 생활에서 소진되는 몸과 마음을 편안하게 하는 방법을 소개합니다.

※ 이 트립은 원칙적으로 매주 금요일 진행됩니다. 다른 요일에 트립 참가를 원하신다면 날짜와 인원 수를 알려주세요. 최대한 트립을 진행해 드립니다.','승인완료','외한',140349089,to_date('20/01/01','RR/MM/DD'),129);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (50,44,'레진공예 체험',10,to_date('20/01/01','RR/MM/DD'),to_date('20/01/31','RR/MM/DD'),'1',40000,'제주특별자치도 제주시 구좌읍 상하도길 46-16','방문하시면 음료나 차를 드시면서 인사를 나누고
레진재료를 보면서 설명해드리고 디자인 구상이 끝나면 체험 시작합니다~ 디자인에 따라~ 
제주여행이기에 제주 느낌을 살려서 디자인도 가능합니다
10분에서~ 1시간 소요
완성품은 가져가셔도 되고 택배 요청하셔도됩니다','승인완료','새마을금고',140349080,to_date('20/01/01','RR/MM/DD'),139);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (51,63,'제주 눈꽃 트래킹 그리고 캠핑피크닉',9,to_date('20/01/01','RR/MM/DD'),to_date('20/01/17','RR/MM/DD'),'4.5',90000,'제주특별자치도 제주시 어영길 1-1','1,중문초등학교 정문 앞에서 만납니다.
2,택시타고 안덕쓰레기매립장 앞으로 이동합니다
3,돌오름임도 입구에서 삼나무숲길 지나 돌오름을 등산한 후에  내리막길을  따라 옛 안덕쓰레기매립장 방면으로 하산합니다. (휴식시간포함 3시간, 간식과 따뜻한 차 섭취)
4,하산지점 부근 삼나무숲에서 점심 식사를 합니다.(1시간)','승인완료','기업',150349081,to_date('20/01/01','RR/MM/DD'),10);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (52,63,'오늘의 기분을 담다, 감성 위빙 데이트',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/18','RR/MM/DD'),'3',50000,'제주특별자치도 제주시 구좌읍 충렬로 147-19','6세 이상부터 성인까지 함께 해보실 수 있는 프로그램이며 내가 좋아하는 느낌의 털실을 직조하여 쌓아갑니다. 알록달록, 색과 질감이 서로 다르지만 한데 어우러지는 모습을 경험해보세요.

게스트들이 서로 잠깐 소개하는 시간을 가지고 다과를 즐기며 즐겁게 수다데이트를 하며 진행됩니다.
서로 다른 곳에서 왔지만 "제주"라는 이름으로 한 공간에 모여 이야기꽃을 피울 수 있음에 감사함을 느낍니다.

나만의 색감으로 타피스트리를 만들며 행복한 시간을 가져보세요. 마무리까지 도와드리며 위빙 기법 세가지를 배워보실 수 있습니다. 작업은 두시간 동안 진행되니 여유를 가지고 방문해주세요!

완성된 타피스트리를 들고 제주 돌담앞에서 ''찰칵'' 사진도 찍어 드릴게요.','승인완료','기업',150349082,to_date('20/01/01','RR/MM/DD'),144);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (53,41,'산방산에서 쪽염색 체험(문양염)하기',5,to_date('20/01/01','RR/MM/DD'),to_date('20/01/23','RR/MM/DD'),'1.5',25000,'제주특별자치도 제주시 한림읍 일주서로 5673','[문양염 체험하기]
문양염은 식물이나 자연, 풍경 등을 그려서 이를 천에 옮긴 후 방염풀을 이용하여 쪽염색을 하는 것입니다. 

체험자는 다음과 같은 과정으로 문양염 트립을 진행합니다.

1. 도안선택 - 식물이나 자연, 또는 풍경 등을 그린 형지를 선택합니다.
2. 방염풀 바르기 - 원단(47cm * 47cm)에 형지를 올리고 방염풀을 바릅니다.
3. 쪽염색 - 방염풀이 마르면 원단에 쪽물을 들입니다.
4. 완성 - 쪽물을 들인 후 수세를 하고 완성합니다.

시작과 끝까지 각 과정에서의 단계를 저의 지도에 따라 미리 준비된 준비물과 소재, 그리고 염재를 이용하여 선택하신 기법으로 천연염색을 직접 시작합니다.','승인완료','외한',150349083,to_date('20/01/01','RR/MM/DD'),152);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (55,63,'힐링타임: 명상&비건브런치',10,to_date('20/01/01','RR/MM/DD'),to_date('20/01/30','RR/MM/DD'),'1.5',43000,'제주특별자치도 제주시 한경면 고락로 100','1. 스트레칭  (몸과 마음을 이완하기 위해 요가 동작을 기반으로 한 메디스트레칭을 합니다.)
2. 명상    (제주 자연속에서 몸과 마음을 살펴볼 수 있는 명상을 경험합니다.)      
3.  걷기 명상 (몸의 움직임을 느껴보는 명상을 합니다. 기후에 따라 야외 맨발걷기를 병행합니다.) 
4. 비건브런치   (제주로컬푸드와 유기농재료로  전문가에 의해 구성된 비건브런치 세트를 경험해 봅니다.)','승인완료','기업',150349085,to_date('20/01/01','RR/MM/DD'),277);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (56,62,'제주말 만들기 @ 대평리 바닷가 조용한 카페',10,to_date('20/01/01','RR/MM/DD'),to_date('20/01/23','RR/MM/DD'),'1.5',15000,'제주특별자치도 제주시 무근성7길 16-13','미리 재단되어진 천과, 모든 부자재가 제공되어 집니다. 여러종류가 있어서 고르시면 됩니다.
시작하여 끝날 때 까지는 1시간 가량 소요됩니다. 따뜻한 차 한잔이 제공됩니다. 예쁜 카페인지라 물론 더 머무셔도 됩니다.
덤으로 제주 정착에 대한 궁금한 점은 성실히 상담해 드립니다.','승인완료','국민',150349086,to_date('20/01/01','RR/MM/DD'),276);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (57,83,'한복 입고 제주 용두암 산책 & 사진 촬영',7,to_date('20/01/01','RR/MM/DD'),to_date('20/01/20','RR/MM/DD'),'2',40000,'제주특별자치도 서귀포시 성산읍 한도로 117','Let''s meet at Miya''s closet which is hanbok rental boutique near Yongduam seaside. Then we will choose to wear gorgeous Korean clothes "Hanbok" Of course You should carry bags and hats like an actor of  Korean drama. 
We will walk to Yongduam which is a dragon head rock.  Surely Daniel who is a professional photographer will take photos of you during this journey with wonderful Jeju Sea  and flowers.  You will see the Haenyeo, female diver for seafood in the sea. It''s a traditional way of living in Jeju.  We will tell you the story about Haenyeo since some Haenyeo lives nearby, If we are luck we can talked to Haenyeo, taking a photo together. We will step down to dragon head rock then will see the seafood Haenyeo''s are selling. 
Then we will move to "Yongyeon valley" which is a small but beautiful meet up area between river from the Halla mt. and Jeju sea. We will walk across the little bridge and take a rest in the paragon which made with Korean Hanbok style. 
Many previous nobles were sent to exile in jeju island in Chosun dynasty, Local governor would have treated them here boating in yongyeon valley so that they could fill their empty hearty with beautiful nature. All these routes are walking distance.','승인완료','국민',150349087,to_date('20/01/01','RR/MM/DD'),275);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (58,62,'너와 내가 함께 만드는 가방',2,to_date('20/01/01','RR/MM/DD'),to_date('20/01/27','RR/MM/DD'),'3.5',138000,'제주특별자치도 제주시 한림읍 협재1길 19-8','# 트립 기본 요금 가방 사이즈는 가로 155mm 세로 110mm 옆면폭 28mm 입니다 

# B - 가방 사이즈는 가로 180mm 세로 105mm 옆면폭 30mm 입니다 (현장에서 추가 요금 지불)
# C - 가방 사이즈는 가로 210mm 세로 125mm 옆면폭 40mm 입니다 (현장에서 추가 요금 지불)

가방 size 선택해서 host 에게 알려주세요¡
선택하지 않으면 기본 size 가방 제공됩니다.

제주도는 친환경 지역입니다
제주환경에 맞는 좋은 재료를 사용합니다.

#가죽 - 친환경 이태리 베지터블 가죽 (가공방식 ~ 나무껍질의 탄닌 성분으로 가죽염색
#실 _ 이태리 수용성 접착제(나쁜 냄새가 나지 않습니다)

가방 만들기는 사진 속 색깔 중 한가지를 미리 선택해서 저에게 메세지를 보내주세요
(없는 색깔이 있을 수 있습니다)

아래 작업 순서를 참고해주세요

원활한 진행을 위해서 미리 가죽 재단해 놓습니다.
게스트는 가죽에 가죽로션을 바르고, 크리져로 선을 긋는다
그리프(치즐)을 이용해서 망치질을 해서 바느질 구멍을 뚫는다
친환경 접착제를 이용해서 가죽을 붙힌다
바늘 2개(새들스티치)를 이용해서 바느질 한다

#새들스티치(Saddle Stitch)_왁스를 입힌 프랑스 린넨 실을 바늘 2개에 연결한다
왼손, 오른손에 바늘 한 개씩 잡는다
뚫어 놓은 가죽에 한번씩 넣어준다
두 번 바느질한 효과가 난다 - 하나의 스티치가 끊어지더라도 다른 하나의 스트치가 남아 있기 때문에 튼튼한 제품이 된다

#포니 - 양손을 사용하는 손바느질을 할때 가죽을 잡아 줍니다.','승인완료','국민',150349088,to_date('20/01/01','RR/MM/DD'),76);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (59,63,'펀치니들 타피스트리, 콕콕콕 함께 만들어요',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/20','RR/MM/DD'),'3',60000,'제주특별자치도 서귀포시 성산읍 일출로 268','청소년부터 어른까지 할 수 있는 프로그램이며 인형놀이를 하듯 내 모습을 담아봅니다.
지름 15cm 의 수틀에 선택한 디자인의 실루엣 도안을 구성하여 작업합니다. 

게스트들이 서로 잠깐 소개하는 시간을 가지고 다과를 즐기며 즐겁게 수다데이트를 하며 진행됩니다.
서로 다른 곳에서 왔지만 "제주"라는 이름으로 한 공간에 모여 이야기꽃을 피울 수 있음에 감사함을 느낍니다.

나만의 디자인으로 원형수틀 타피스트리로 완성되는 아이템이며 부분적인 컬러와 디자인 변경은 가능합니다. 도안은 예약 후 별도로 문의주세요!  (tel. 01064397837)
마무리까지 도와드리며 펀치니들의 드로잉기법을 알려드립니다.
 작업은 세시간 동안 진행되니 여유를 가지고 방문해주세요!

완성된 작품을 들고 제주 돌담앞에서 ''찰칵'' 사진도 찍어 드릴게요.','승인완료','KEB하나',150349089,to_date('20/01/01','RR/MM/DD'),77);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (60,63,'제주바다캔들 만들기, 제주도의 바다를 집으로 가져가세요~!!',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/25','RR/MM/DD'),'1',38500,'제주특별자치도 제주시 현사길 17-1','핸즈웍스 방문을 환영합니다!^^
바다캔들 만들기는 어린이(6세 이상)부터 누구든 만들 수 있습니다.

**캔들체험은 최소 40분~최대 1시간의 수업시간입니다
    따라서, 10분 이상 지각 시 수업참여가 불가능합니다!!!**

핸즈웍스의 모든 재료는 제주의 자연에서 온 재료로
인공적인 색상의 모래와 재료를 일절 사용하지 않습니다.
제주의 자연으로 바다캔들을 만들어보세요.

''제주바다캔들''은 투명한 바다를 표현하기 위해 젤왁스를 이용합니다.
방문하시면, 두 가지 종류의 유리용기 중 하나를 선택하시게 됩니다.
그런 후, 바다모래를 원하시는 만큼 용기 바닥에 부어줍니다.
원하는 백사장이 만들어 졌다면, 모래 위에 작은 돌과 마모된 조개껍질을 부어줍니다.
조개껍질 위에는 바다의 해초들이 넘실될 수 있도록 해초들을 심어주세요.
제주도의 가장 특별한 돌인 화산석이 암초처럼 보일 수 있게 암초 사이에 둡니다.
이제, 아름답게 장식된 나만의 바다를 젤왁스로 채워줍니다.

푸르른 바다색감을 원하는 만큼의 진하기로 표현할 수 있습니다.
만들어진 젤왁스를 자신의 바다에 채워주면 완성됩니다.
젤왁스가 어느 정도 굳어지면, 투명박스에 넣어 집으로 가져갑니다.
이제, 제주바다가 당신 곁에 늘 함께 할 것입니다.
총 소요시간은 30분에서 1시간 이내 입니다.','승인완료','외한',150349080,to_date('20/01/01','RR/MM/DD'),244);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (61,45,'Visit to the Studio of Jeju Artist',5,to_date('20/01/01','RR/MM/DD'),to_date('20/01/22','RR/MM/DD'),'1.5',15000,'제주특별자치도 제주시 구좌읍 한동북1길 8-21','All activities take place in a private studio located close to Jeju Airport.First, I have a time to introduce Jeju''s unique culture to the guests.And You''ll hear about my oil paintings on display in the workshop.Also, you have time to think about the current state of Jeju through simple questions. Next, we will have a simple watercolor experience where we can remember Jeju. After the experience is over, I can give you some advice on your travel plan.','승인완료','우체국',160349081,to_date('20/01/01','RR/MM/DD'),156);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (62,46,'어린왕자 이야기를 작가와 미술화가 작품 벽화를 보고 그곳에 나의벽화를',1,to_date('20/01/01','RR/MM/DD'),to_date('20/01/17','RR/MM/DD'),'1',40000,'제주특별자치도 제주시 애월읍 고내로9길 42','물감으로 벽화를 
매일하루 2시간동안 실제로벽화를 그리는 
체험을 준비했습니다 
각벽에 어린왕자 이야기를 따뜻하고 아름답게 
그려있는 곳을 자연스럽게 다니시면서 다양한 일러스트로 작품과 트릭아트 작품을 보시면서 
어린왕자의 세계로 빠져들어 보시고 직접 그려보는 과정을 경험해볼수 있습니다 
누가나 벽화를 그려보는 쉽지않은 경험을 하실수 
있도록 준비된곳에서 즐거운 시간과 작품활동을  
체험하고 자기많의 작품과
즐거운시간을 만들어 보세요','승인완료','새마을금고',160349082,to_date('20/01/01','RR/MM/DD'),191);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (63,85,'Hanbok Styling & Korea makeup experience',6,to_date('20/01/01','RR/MM/DD'),to_date('20/01/29','RR/MM/DD'),'2',30000,'제주특별자치도 제주시 한림읍 귀덕5길 34','This is  Korean traditional clothes ,Hanbok styling & make-up experience.  It consists of  wearing hanbok & accessories, hair styling and make-up experience. First of all, I will help you to choose the best HANBOK matching with you. Secondly, I will recommend you should choose bags, Shoes and accessories(for woman Norigae, for man hat). Third, make-up experience will be following. We will let you kniw about Korean style make-up and will help you make-up. Eye shadow, Eye-Brow pencil, lipstick, cheek blusher, foundation, eye liner, mascara will be provided. Yet basic cosmetics like face lotion, essence, moisturizing cream and make-up base will not be provided.  You are able to experience how to put on Korean make-up  leaded by me. You will be changed to the main character of Korean Drama. Then you will  be dressed up with hanbok.  Finally hair styling will be done by me.  Yes! Our professional photographer will take photos for you.
We will take professional photos for you will send them later.
I will talk about Korean traditional things and about Jeju tour when Korean Traditional tea is served for you. 
All activities will be done in the shop, Miya''s closet. 
Time : 1. Hanbok & accessories selection (15min.) 2.Make-up(20min.) 3. Wearing hanbok(10min.) 4. Hair(15min.) 5. Taking photos & tea time(30min)','승인완료','KEB하나',160349083,to_date('20/01/01','RR/MM/DD'),163);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (64,43,'산방산에서 쪽염색 체험(스카프 홀치기염)하기',5,to_date('20/01/01','RR/MM/DD'),to_date('20/01/22','RR/MM/DD'),'1.5',35000,'제주특별자치도 제주시 우도면 영일길 156-32','[스카프 홀치기 쪽염색 체험하기]
스카프 홀치기는 염색이 되지 않을 부분(흰부분)을 구슬이나 실, 고무밴드 등을 이용해 묶은 후 쪽염물에 담그고 꺼낸 후 공기와 마찰을 주고 다시 담그고 꺼내는 과정을 2~3회 반복합니다. 물 들이고자 하는 부분이 파랗게 나오면 묶었던 부분을 푼 후 찬물에 깨끗하게 씻은 후 섬유유연제에 담궈 부드럽게 한 후 바람에 말리게 됩니다. 

시작과 끝까지 각 과정에서의 단계를 저의 지도에 따라 미리 준비된 준비물과 소재, 그리고 염재를 이용하여 선택하신 기법으로 천연염색을 직접 시작합니다.','승인완료','기업',160349084,to_date('20/01/01','RR/MM/DD'),339);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (65,42,'유유자적 신선놀음 선셋크루징',10,to_date('20/01/01','RR/MM/DD'),to_date('20/01/22','RR/MM/DD'),'2',50000,'제주특별자치도 서귀포시 중문로105번길 12','요트에 탑승 후 
안전에 관한 설명을 5분 동안 진행합니다.

출항 후에는 바람을 이용한 세일링을 진행하고 
돌아오면서 통영 앞바다를 물들이는
멋진 노을을 감상하며 천천히 돌아들어옵니다.

투어는 약 2시간 가량 진행되며
조류와 바람 등 기상조건에 따라 조금 더 늦어질 수도 있습니다.','승인완료','기업',160349085,to_date('20/01/01','RR/MM/DD'),87);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (66,41,'펀치니들 소품,  하르방과 벚꽃동백',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/23','RR/MM/DD'),'3',50000,'제주특별자치도 제주시 남성로 158-3','청소년부터 어른까지 할 수 있는 프로그램이며 제주를 담은 하르방 인형 또는 오너먼트를 만들어 봅니다.
하르방인형은 입체 인형이며 실 재고에 따라 색을 변경할 수 있어요.
벚꽃동백 오너먼트도 한가지 꽃으로 표현 될 수 있고 종이나 방울을 달기도 합니다.

게스트들이 서로 잠깐 소개하는 시간을 가지고 즐겁게 수다데이트를 하며 진행됩니다.
서로 다른 곳에서 왔지만 "제주"라는 이름으로 한 공간에 모여 이야기꽃을 피울 수 있음에 감사함을 느낍니다.

내 손안에 쏙 들어오는 제주와 관련된 기념품을 만들어보세요.
 마무리까지 도와드리며 펀치니들 하는 방법을 알려드립니다. 
작업은 세시간 동안 진행되니 여유를 가지고 방문해주세요!

완성된 작품을 들고 제주 돌담앞에서 ''찰칵'' 사진도 찍어 드릴게요.','승인완료','외한',160349086,to_date('20/01/01','RR/MM/DD'),36);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (67,42,'Enjoy Photoshoot at Jeju Beach',4,to_date('20/01/01','RR/MM/DD'),to_date('20/01/17','RR/MM/DD'),'2',70202,'제주특별자치도 서귀포시 남원읍 신흥앞동산로35번길 3','We''ll conduct our photoshoot at one of the most favourite beaches in Jeju Island, Gwakji beach. The beach itself is clean and the water is crystal-clear. It is a great location for a photoshoot.','승인완료','KEB하나',160349087,to_date('20/01/01','RR/MM/DD'),270);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (68,121,'보성 관광지 투어와 음식즐기기',6,to_date('20/01/01','RR/MM/DD'),to_date('20/01/20','RR/MM/DD'),'4',75000,'제주특별자치도 서귀포시 안덕면 동광로100번길 20','16년동안 가꾸어온  골망태정원 1시간 산책하고 펜션에서 5분거리에 위치한 대한다원을  1시간을 투어하며 3분거리차박물관1시간관람한다음  10분거리 율포해수욕장으로 이동  30분정도 바닷가 산책한다.  수산물센타에서 해산물구입 해서 해물라면 끓여먹는다음 카페에서 녹차시음후 종료','승인완료','우체국',160349088,to_date('20/01/01','RR/MM/DD'),166);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (69,86,'Trekking and Picking Strawberry',8,to_date('20/01/01','RR/MM/DD'),to_date('20/01/19','RR/MM/DD'),'3',60000,'제주특별자치도 제주시 삼오길 9','You''ll trekking Gotjawal(forest) where refers to rocky areas created by lava flows during volcanic activity for about one hour and half.
These area are growing on terrian where rocks are unevenly scattered.
Gotjawal forests sustain unique ecosystems where a variety of flora
and fauna coexist. 
After trekking forest, you''ll visit strawberry farm to pick them.
You can have them as much as you want also bring a small pack of them.','승인완료','기업',160349089,to_date('20/01/01','RR/MM/DD'),181);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (70,86,'화가가 운영하는 시내 그림공방에서 제주 여행 사진을 그려보세요',8,to_date('20/01/01','RR/MM/DD'),to_date('20/01/31','RR/MM/DD'),'2',29800,'제주특별자치도 서귀포시 대정읍 하모상가로 35-5','부미갤러리
주소: 제주시 은남3길 19번지 1층 카페
화가의 화방, 전시실도 방문하시고 그림도 직접 그려보세요!','승인완료','기업',160349080,to_date('20/01/01','RR/MM/DD'),281);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (71,42,'Enjoy Korean Traditional Culture',3,to_date('20/01/01','RR/MM/DD'),to_date('20/01/26','RR/MM/DD'),'4',40000,'제주특별자치도 서귀포시 천지로 33','First, I will take you to the Nagan-eup Castle.

The beautiful rural landscape will captivate you while you drive for 20 minutes. 
When you arrive at the Nagan-eup Castle where people  live miraculously , you will learn about the history of the Nagan-eup Castle. 

When you enter the Castle, you can experience various folk traditions for free which is held by residents who live there. For example, traditional big drums, natural dyeing, village laundry, planing the tree, traditional swing and other activities will be options.  You can travel in a time that has stopped. It is a time travel into a living museum that encompasses past and present. 

Your host Peter is a master of Korean traditional martial arts. You will have chance can practice Korean traditional martial arts with your host Peter, while moving around the castle. 

When you have finish all your activities, I will guide you to the Suncheon''s traditional market. There you will enjoy shopping and have dinner there.

After dinner, I will guide you back where we met first or where you want.','승인완료','국민',170349081,to_date('20/01/01','RR/MM/DD'),203);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (72,87,'Enjoy Photoshoot at Tea Museum Area',3,to_date('20/01/01','RR/MM/DD'),to_date('20/01/28','RR/MM/DD'),'2',70202,'제주특별자치도 제주시 한림읍 월령3길 36','We''ll conduct our photoshoot at the must-visit place in Jeju, Tea Museum as it is highly recommended when visiting the island.','승인완료','기업',170349082,to_date('20/01/01','RR/MM/DD'),112);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (73,41,'Back to Korean Traditional Past',3,to_date('20/01/01','RR/MM/DD'),to_date('20/01/31','RR/MM/DD'),'4',40000,'제주특별자치도 서귀포시 성산읍 시흥하동로55번길 23-5','First, I will take you to the Nagan-eup Castle.

The beautiful rural landscape will captivate you while you drive for 20 minutes. 
When you arrive at the Nagan-eup Castle where people  live miraculously, you will learn about the history of the Nagan-eup Castle. 

When you enter the Castle, you can experience various folk traditions for free which is held by residents who live there. For example, traditional big drums, natural dyeing, village laundry, planing the tree, traditional swing and other activities will be options.  You can travel in a time that has stopped. It is a time travel into a living museum that encompasses past and present.
Also, you will have lunch made by with local food in the stone wall.

Your host Peter is a master of Korean traditional martial arts. After lunch, you will have chance can practice Korean traditional martial arts with your host Peter, while moving around the castle. 

When you have finish all your activities, I will guide you back where we first met or where you want.','승인완료','기업',170349083,to_date('20/01/01','RR/MM/DD'),269);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (1954,43,'감귤농장에서 감귤따기',10,to_date('20/01/09','RR/MM/DD'),to_date('20/01/31','RR/MM/DD'),'1',5000,'제주특별자치도 서귀포시 안덕면 한창로 104  ','감귤따기 함께 해요~~ 맛있는 감귤 마음껏 드셔도 됩니다. 감귤체험이 단돈 오천원!!!','심사대기','외한',110349082169,to_date('20/01/06','RR/MM/DD'),204);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (1955,43,'제주도 승마체험',10,to_date('20/01/08','RR/MM/DD'),to_date('20/01/31','RR/MM/DD'),'2',30000,'제주특별자치도 서귀포시 안덕면 한창로 104  ','해발 530m에 위치한 어승생승마장은 한라산과 제주 바다가 한눈에 보이는 경치좋은 승마장입니다.
날씨가 좋은 날에는 에메랄드 빛 제주바다를 볼 수 있고, 멀리 추자도군도까지 보입니다.
임금이 타던 명마를 생산했다고 알려진 어승생오름 자락에 위치해 웅장한 한라산이 바로 눈앞에서 서 있습니다.
구름이 승마장 아래로 낮게 깔린 날은 어승생승마장 최고의 하이라이트입니다.
방목한 말들과 친해질 수 있습니다.','심사대기','KEB하나',110349082169,to_date('20/01/06','RR/MM/DD'),204);
Insert into PROJECT.EXPERIENCE (EXCODE,MEMBERCODE,EXNAME,EXPEOPLE,EXSTARTDATE,EXENDDATE,EXTIME,EXPRICE,EXADDRESS,EXEXPLAIN,EXAPPROVAL,EXBANK,EXACCOUNT,EXREGDATE,HOUSECODE) values (1952,43,'올레길 투어',5,to_date('20/01/07','RR/MM/DD'),to_date('20/01/31','RR/MM/DD'),'2',10000,'제주특별자치도 서귀포시 성산읍 신양로122번길 29  ','제주도 올레길 투어 하러 오세여~~~','승인거절','KEB하나',110349082169,to_date('20/01/06','RR/MM/DD'),121);
--------------------------------------------------------
--  Constraints for Table EXPERIENCE
--------------------------------------------------------

  ALTER TABLE "PROJECT"."EXPERIENCE" MODIFY ("EXCODE" NOT NULL ENABLE);
  ALTER TABLE "PROJECT"."EXPERIENCE" MODIFY ("MEMBERCODE" NOT NULL ENABLE);

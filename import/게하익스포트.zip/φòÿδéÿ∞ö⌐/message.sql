--------------------------------------------------------
--  파일이 생성됨 - 일요일-6월-14-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table MESSAGE
--------------------------------------------------------

  CREATE TABLE "PROJECT"."MESSAGE" 
   (	"MSGCODE" NUMBER(5,0), 
	"MEMBERCODE" NUMBER(10,0), 
	"MSGCONTENT" VARCHAR2(300 BYTE), 
	"MSGDATE" DATE, 
	"MSGCHECK" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into PROJECT.MESSAGE
SET DEFINE OFF;
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (49,41,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (70,41,'(체험) 100년된 제주전통흙집에서 흙으로 만드는 예술소품이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (50,41,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (1,41,'(체험) 하이킹이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('19/12/23','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (71,41,'(체험) 사진작가와 함께하는 비밀의 숲 걷기 그리고 인생샷까지이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (2,41,'(체험) 하이킹이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('19/12/23','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (3,42,'(체험) 하이킹이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('19/12/23','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (4,86,'(체험) 하이킹이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('19/12/24','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (5,43,'(체험) 하이킹이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('19/12/24','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (6,43,'(체험) 하이킹이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('19/12/24','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (7,41,'(체험) 하이킹이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('19/12/24','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (9,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (10,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (11,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (12,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (13,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (14,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (15,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (16,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (17,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (18,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (19,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (20,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/26','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (21,21,'(체험) 하이킹이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('19/12/27','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (21,121,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/30','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (22,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/30','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (23,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/30','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (24,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/30','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (41,62,'(체험) 지연체험이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('19/12/30','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (25,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/30','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (26,45,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/12/30','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (41,121,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (42,45,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (43,45,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (61,41,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (62,41,'(체험) 제주도 오름 투어와 야경 스냅촬영이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (63,41,'(체험) 눈썰매타고 캠핑피크닉이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (44,45,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (45,45,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (46,63,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (64,63,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (65,41,'(체험) 오름의 여왕 다랑쉬오름 얼리버드 새벽 트래킹과 사진팁이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (66,41,'(체험) 오름의 여왕 다랑쉬오름 얼리버드 새벽 트래킹과 사진팁이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (67,41,'(체험) 오름의 여왕 다랑쉬오름 얼리버드 새벽 트래킹과 사진팁이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (68,41,'(체험) 제주바다캔들 만들기, 제주도의 바다를 집으로 가져가세요~!!이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (69,41,'(체험) 너와 내가 함께 만드는 가방이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (47,63,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (48,121,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/02','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (51,63,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (72,63,'(체험) 반짝반짝 나만의 유리 썬캐쳐 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (73,41,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (74,43,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (52,146,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (75,43,'(체험) 제주도 오름 투어와 야경 스냅촬영이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (76,146,'(체험) <2인가격>제주에서 나와 우리만의 힐링&아쉬탕가요가<1:1/2인/소규모>이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (53,147,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (54,21,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (77,41,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (55,41,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (56,41,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (78,41,'(체험) 반짝반짝 나만의 유리 썬캐쳐 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (79,41,'(체험) 반짝반짝 나만의 유리 썬캐쳐 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (57,146,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (61,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (81,62,'(체험) 반짝반짝 나만의 유리 썬캐쳐 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (82,62,'(체험) 반짝반짝 나만의 유리 썬캐쳐 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (62,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (63,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (64,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (65,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (66,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (83,62,'(체험) 반짝반짝 나만의 유리 썬캐쳐 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (84,43,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (85,43,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (86,62,'(체험) 반짝반짝 나만의 유리 썬캐쳐 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (87,41,'(체험) 반짝반짝 나만의 유리 썬캐쳐 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (88,62,'(체험) 함덕해수욕장 옆 서우봉 오름을 걷고 인생사진도 남겨보세요이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (67,21,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (89,62,'(체험) 함덕해수욕장 옆 서우봉 오름을 걷고 인생사진도 남겨보세요이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (90,161,'(체험) 제주 숲속 알파카와 함께 하는 힐링 체험이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (91,161,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (92,161,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (93,161,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (94,161,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (95,161,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (96,161,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (68,21,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (97,161,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (98,161,'(체험) 사진가와 함께 하는 제주바다산책이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (99,62,'(체험) 함덕해수욕장 옆 서우봉 오름을 걷고 인생사진도 남겨보세요이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (100,62,'(체험) 함덕해수욕장 옆 서우봉 오름을 걷고 인생사진도 남겨보세요이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (101,21,'(체험) 반짝반짝 나만의 유리 썬캐쳐 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/04','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (102,41,'(체험) 제주도 오름 투어와 야경 스냅촬영이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (103,43,'(체험) 제주도 오름 투어와 야경 스냅촬영이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (104,41,'(체험) 제주 숲속 알파카와 함께 하는 힐링 체험이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (105,41,'(체험) 프렌치감성 빈티지캔들 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (106,41,'(체험) 100년된 제주전통흙집에서 흙으로 만드는 예술소품이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (107,43,'(체험) 제주 숲속 알파카와 함께 하는 힐링 체험이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (108,43,'(체험) 프렌치감성 빈티지캔들 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (69,147,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (70,147,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (71,147,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (72,147,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (73,147,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (74,42,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (75,162,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (76,162,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (77,147,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (78,147,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (79,162,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (80,162,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (81,162,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('19/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (82,163,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (109,163,'(체험) 제주 숲속 알파카와 함께 하는 힐링 체험이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (110,62,'(체험) 제주 숲속 알파카와 함께 하는 힐링 체험이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (83,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (84,41,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (85,41,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (86,165,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (87,165,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (111,46,'(체험) 제주 숲속 알파카와 함께 하는 힐링 체험이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (88,121,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (89,121,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (90,43,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (91,43,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (92,147,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (93,83,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (94,43,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (95,43,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (96,43,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (97,21,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (98,87,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (99,63,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (112,63,'(체험) 사진작가와 함께하는 비밀의 숲 걷기 그리고 인생샷까지이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (100,163,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (101,163,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (102,166,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (103,163,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (104,163,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (105,163,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (106,163,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (107,163,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (108,168,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (109,170,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (113,170,'(체험) 제주 숲속 알파카와 함께 하는 힐링 체험이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/06','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (4,163,'(체험) 제주 숲속 알파카와 함께 하는 힐링 체험이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/11','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (5,163,'(체험) 제주 숲속 알파카와 함께 하는 힐링 체험이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/01/11','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (21,62,'(체험) 반짝반짝 나만의 유리 썬캐쳐 만들기이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/02/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (21,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/02/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (22,62,'게스트하우스 예약완료되었습니다. 예약목록을 확인해보세요',to_date('20/02/03','RR/MM/DD'),'읽지 않음');
Insert into PROJECT.MESSAGE (MSGCODE,MEMBERCODE,MSGCONTENT,MSGDATE,MSGCHECK) values (41,62,'(체험) 함덕해수욕장 옆 서우봉 오름을 걷고 인생사진도 남겨보세요이 예약 완료 되었습니다. 예약 목록을 확인해보세요',to_date('20/02/13','RR/MM/DD'),'읽지 않음');
--------------------------------------------------------
--  Constraints for Table MESSAGE
--------------------------------------------------------

  ALTER TABLE "PROJECT"."MESSAGE" MODIFY ("MSGCODE" NOT NULL ENABLE);
  ALTER TABLE "PROJECT"."MESSAGE" MODIFY ("MSGCHECK" NOT NULL ENABLE);

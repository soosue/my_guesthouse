--------------------------------------------------------
--  파일이 생성됨 - 일요일-6월-14-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table LOCAL
--------------------------------------------------------

  CREATE TABLE "PROJECT"."LOCAL" 
   (	"NAME" VARCHAR2(20 BYTE), 
	"LOCAL" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into PROJECT.LOCAL
SET DEFINE OFF;
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('애월읍','jejuWest');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('한경면','jejuWest');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('한림읍','jejuWest');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('건입동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('노형동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('도남동 ','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('도련일동 ','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('봉개동 ','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('삼도동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('삼양동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('아라동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('연동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('영평동 ','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('오라동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('외도동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('용담동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('이도동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('일도동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('해안동 ','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('화북동','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('이호동  ','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('도두동 ','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('추자면 ','jeju');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('구좌읍 ','jejuEast');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('우도면 ','jejuEast');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('조천읍','jejuEast');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('표선면 ','seoguipoEast');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('남원읍 ','seoguipoEast');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('성산읍','seoguipoEast');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('강정동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('대포동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('동홍동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('법환동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('보목동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('상예동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('상효동','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('색달동','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('서귀동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('서홍동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('신효동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('중문동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('토평동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('하예동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('하원동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('하효동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('호근동','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('영천동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('효돈동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('송산동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('정방동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('중앙동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('천지동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('대륜동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('대천동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('중문동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('예래동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('서호동 ','seoguipo');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('안덕면','seoguipoWest');
Insert into PROJECT.LOCAL (NAME,LOCAL) values ('대정읍','seoguipoWest');

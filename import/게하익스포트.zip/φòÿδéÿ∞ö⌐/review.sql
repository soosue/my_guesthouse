--------------------------------------------------------
--  파일이 생성됨 - 일요일-6월-14-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table REVIEW
--------------------------------------------------------

  CREATE TABLE "PROJECT"."REVIEW" 
   (	"RESERVECODE" NUMBER(5,0), 
	"MEMBERCODE" NUMBER(10,0), 
	"REVDATE" DATE, 
	"REVCONTENT" VARCHAR2(1000 BYTE), 
	"REVRATE" NUMBER(5,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into PROJECT.REVIEW
SET DEFINE OFF;
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (155,162,to_date('20/01/06','RR/MM/DD'),'이 집 뭔가 너무 이상하지만 좋습니다',5);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (162,163,to_date('20/01/06','RR/MM/DD'),'아직 가보진 않았는데 좋을거 같아요!!',4);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (163,83,to_date('20/01/06','RR/MM/DD'),'와우 이 집 제주도 맛집',4);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (164,41,to_date('20/01/06','RR/MM/DD'),'제주 관광명소 중문관광단지 앞이라서 너무 좋아요 *^^* 또 갈게요 @------',5);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (165,62,to_date('20/01/06','RR/MM/DD'),'제주도 한 가운데라 교통이 너무 좋습니다. 제주도 서부쪽이랑 중부 구경하실 분들에게 추천해요.',5);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (158,147,to_date('20/01/06','RR/MM/DD'),'아주 좋습니다!!',4);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (166,165,to_date('20/01/06','RR/MM/DD'),'인스타감성 낭낭하네요',5);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (167,165,to_date('20/01/06','RR/MM/DD'),'인생사진 건졌습니다..^^',4);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (172,43,to_date('20/01/06','RR/MM/DD'),'생각보다 너무 좋아서 놀랐네요... 인스타 감성 넘치는 숙소 굿굿',4);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (174,43,to_date('20/01/06','RR/MM/DD'),'게하 파티 너무 즐거웠어요~~',4);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (177,21,to_date('20/01/06','RR/MM/DD'),'여기 인기 많아서 겨우 예약 했어요 굿굿',5);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (175,43,to_date('20/01/06','RR/MM/DD'),'주변이 조용해서 좋았습니다. 귤 농장 근처라 귤도 주셨는데 너무 맛있었어요. 친절하신 사장님 덕분에 잘 쉬다 갑니다.',4);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (178,87,to_date('20/01/06','RR/MM/DD'),'외국인들이 자주 이용하는 게하인지 외국인들이 많아서 외국간 기분이었어요 ㅋㅋㅋㅋㅋㅋㅋㅋ즐거웠습니다',4);
Insert into PROJECT.REVIEW (RESERVECODE,MEMBERCODE,REVDATE,REVCONTENT,REVRATE) values (180,163,to_date('20/01/06','RR/MM/DD'),'요호호~',5);
--------------------------------------------------------
--  Constraints for Table REVIEW
--------------------------------------------------------

  ALTER TABLE "PROJECT"."REVIEW" MODIFY ("RESERVECODE" NOT NULL ENABLE);

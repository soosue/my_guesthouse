--------------------------------------------------------
--  DDL for Sequence HOUSE_HOUSECODE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PROJECT"."HOUSE_HOUSECODE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE ;

--------------------------------------------------------
--  DDL for Sequence MEMBER_MEMBERCODE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PROJECT"."MEMBER_MEMBERCODE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 81 CACHE 20 NOORDER  NOCYCLE ;

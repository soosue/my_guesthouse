--------------------------------------------------------
--  Constraints for Table WISHLIST
--------------------------------------------------------

  ALTER TABLE "PROJECT"."WISHLIST" MODIFY ("MEMBERCODE" NOT NULL ENABLE);
  ALTER TABLE "PROJECT"."WISHLIST" MODIFY ("HOUSECODE" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table REVIEW
--------------------------------------------------------

  ALTER TABLE "PROJECT"."REVIEW" MODIFY ("RESERVECODE" NOT NULL ENABLE);

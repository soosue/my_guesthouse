--------------------------------------------------------
--  DDL for Sequence EXRESERVE_EXRESERVECODE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PROJECT"."EXRESERVE_EXRESERVECODE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;

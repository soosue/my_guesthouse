--------------------------------------------------------
--  DDL for Sequence MESSAGE_MSGCODE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PROJECT"."MESSAGE_MSGCODE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;

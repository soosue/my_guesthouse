--------------------------------------------------------
--  Constraints for Table MESSAGE
--------------------------------------------------------

  ALTER TABLE "PROJECT"."MESSAGE" MODIFY ("MSGCODE" NOT NULL ENABLE);
  ALTER TABLE "PROJECT"."MESSAGE" MODIFY ("MSGCHECK" NOT NULL ENABLE);

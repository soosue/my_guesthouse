--------------------------------------------------------
--  Constraints for Table EXREMAIN
--------------------------------------------------------

  ALTER TABLE "PROJECT"."EXREMAIN" MODIFY ("EXCODE" NOT NULL ENABLE);

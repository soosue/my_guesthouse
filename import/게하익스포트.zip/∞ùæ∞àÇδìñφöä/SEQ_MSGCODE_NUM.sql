--------------------------------------------------------
--  DDL for Sequence SEQ_MSGCODE_NUM
--------------------------------------------------------

   CREATE SEQUENCE  "PROJECT"."SEQ_MSGCODE_NUM"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 41 CACHE 20 NOORDER  NOCYCLE ;

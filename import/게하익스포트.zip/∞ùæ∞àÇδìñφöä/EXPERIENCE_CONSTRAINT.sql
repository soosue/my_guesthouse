--------------------------------------------------------
--  Constraints for Table EXPERIENCE
--------------------------------------------------------

  ALTER TABLE "PROJECT"."EXPERIENCE" MODIFY ("EXCODE" NOT NULL ENABLE);
  ALTER TABLE "PROJECT"."EXPERIENCE" MODIFY ("MEMBERCODE" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table EXREVIEW
--------------------------------------------------------

  ALTER TABLE "PROJECT"."EXREVIEW" MODIFY ("EXRESERVECODE" NOT NULL ENABLE);

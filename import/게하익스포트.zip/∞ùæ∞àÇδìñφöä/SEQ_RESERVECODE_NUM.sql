--------------------------------------------------------
--  DDL for Sequence SEQ_RESERVECODE_NUM
--------------------------------------------------------

   CREATE SEQUENCE  "PROJECT"."SEQ_RESERVECODE_NUM"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 101 CACHE 20 NOORDER  NOCYCLE ;

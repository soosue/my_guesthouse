--------------------------------------------------------
--  Constraints for Table EXWISHLIST
--------------------------------------------------------

  ALTER TABLE "PROJECT"."EXWISHLIST" MODIFY ("MEMBERCODE" NOT NULL ENABLE);
  ALTER TABLE "PROJECT"."EXWISHLIST" MODIFY ("EXCODE" NOT NULL ENABLE);
